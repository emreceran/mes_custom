﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class SendAgainMethods
    {
        public static void BelgeleriTekrarGonder(connectorService methods, string vergiTcKimlikNo)
        {
            string[] ettn = { "B0E18A27-7A37-4F41-9006-59C437E66E5F" };
            string belgeTuru = "FATURA_UBL";  //FATURA (CS-XML),UYGULAMA_YANITI (CS-XML); FATURA_UBL (direk UBL), UYGULAMA_YANITI_UBL (direk UBL)

            bool tekrarGonderildiMi = methods.belgeleriTekrarGonder(vergiTcKimlikNo, ettn, belgeTuru);

            if (tekrarGonderildiMi.Equals(true))
            {
                Console.WriteLine("Tekrar gönderildi. ");
            }
            else
            {
                Console.WriteLine("Gönderilemedi. ");
            }
        }

        public static void BelgeleriTekrarGonderBelgeOid(connectorService methods, string vergiTcKimlikNo)
        {
            string[] belgeOid = { "19jh8yfg8013l3" };
            string belgeTuru = "FATURA_UBL"; //FATURA (CS-XML),UYGULAMA_YANITI (CS-XML); FATURA_UBL (direk UBL), UYGULAMA_YANITI_UBL (direk UBL)

            bool tekrarGonderildiMi = methods.belgeleriTekrarGonderBelgeOid(vergiTcKimlikNo, belgeOid, belgeTuru);

            if (tekrarGonderildiMi.Equals(true))
            {
                Console.WriteLine("Tekrar gönderildi. ");
            }
            else
            {
                Console.WriteLine("Gönderilemedi. ");
            }
        }

        public static void BelgeleriTekrarGonderYerelBelgeNo(connectorService methods, string vergiTcKimlikNo)
        {
            string[] yerelBelgeNo = { "B0E18A27-7A37-4F41-9006-59C437E66E5F" };
            string belgeTuru = "FATURA_UBL";  //FATURA (CS-XML),UYGULAMA_YANITI (CS-XML); FATURA_UBL (direk UBL), UYGULAMA_YANITI_UBL (direk UBL)

            bool tekrarGonderildiMi = methods.belgeleriTekrarGonderYerelBelgeNo(vergiTcKimlikNo, yerelBelgeNo, belgeTuru);

            if (tekrarGonderildiMi.Equals(true))
            {
                Console.WriteLine("Tekrar gönderildi. ");
            }
            else
            {
                Console.WriteLine("Gönderilemedi. ");
            }
        }
    }
}
