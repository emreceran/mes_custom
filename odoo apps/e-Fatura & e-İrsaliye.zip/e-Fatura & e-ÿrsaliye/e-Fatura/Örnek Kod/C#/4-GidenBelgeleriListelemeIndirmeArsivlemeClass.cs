﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class GidenBelgeleriListelemeIndirmeArsivlemeClass
    {
        public static void GidenBelgeleriListele(connectorService methods, string vKN_TCKN)
        {
            try
            {
                gidenBelgeleriListeleParametreleri parametreler = new gidenBelgeleriListeleParametreleri();

                parametreler.vkn = vKN_TCKN;
                parametreler.belgeTuru = "IRSALIYE_YANITI_UBL"; //FATURA (CS-XML),UYGULAMA_YANITI (CS-XML); FATURA_UBL (direk UBL), UYGULAMA_YANITI_UBL (direk UBL), 
                                                                //IRSALIYE_YANITI_UBL, IRSALIYE_YANITI (CS-XML), IRSALIYE_UBL, IRSALIYE (CS-XML)
                parametreler.baslangicGonderimTarihi = "20180501";
                parametreler.bitisGonderimTarihi = "20180517";

                serviceReturnType[] gidenBelListele = methods.gidenBelgeleriListele(parametreler);

                foreach (gidenBelgeleriListeleData item in gidenBelListele)
                {
                    string belgeOid = item.belgeOid;
                    string ettn = item.ettn;
                    string yerelBelgeNo = item.yerelBelgeNo;
                    string alimZamani = item.alimZamani;
                    string alimDurumu = item.alimDurumu;
                    string hataMesaji = item.hataMesaji;
                    string islemYapanVkn = item.islemYapanVkn;
                    string kullaniciKodu = item.kullaniciKodu;
                    string kaynak = item.kaynak;

                    Console.WriteLine("belgeOid: " + belgeOid +
                                      "\n ettn: " + ettn +
                                      "\n yerelBelgeNo: " + yerelBelgeNo +
                                      "\n alimZamani:" + alimZamani +
                                      "\n alimDurumu: " + alimDurumu +
                                      "\n hataMesaji: " + hataMesaji +
                                      "\n islemYapanVkn: " + islemYapanVkn +
                                      "\n kullaniciKodu: " + kullaniciKodu +
                                      "\n kaynak: " + kaynak);
                }
            }
            catch (Exception exp)
            {

                Console.WriteLine(exp.Message);
            }

        }

        public static void GidenBelgeleriIndir(connectorService methods, string vKN_TCKN)
        {
            Console.WriteLine("\n\nGidenBelgeleriIndir");
            try
            {
                string vergiTcKimlikNo = vKN_TCKN;
                string[] belgeOidListesi = new string[100];// { "0niv9c1a7e10x1", "0niv9c1a7e10wr", "0niv9c1a7e10sq", "0niv9c1a7e10so", "0niv9c1a7e10sl", "0niv9c1a7e10s8", "0niv9c1a7e10s2", "0niv9c1a7e10rw", "0niv9c1a7e10ra", "0niv9c1a7e10r6", "0niv9c1a7e10qt", "0niv9c1a7e10qj", "0niv9c1a7e10qh", "0niv9c1a7e10q8", "0niv9c1a7e10q4", "0niv9c1a7e10q3", "0niv9c1a7e10pz", "0niv9c1a7e10pt", "0niv9c1a7e10ot", "0niv9c1a7e10or" };
                belgeOidListesi[0] = "0nj3v6xguf12g5";   //"0nj0xvaycg103j";
                string belgeTuru = "FATURA"; //FATURA (CS-XML),UYGULAMA_YANITI (CS-XML); FATURA_UBL (direk UBL), UYGULAMA_YANITI_UBL (direk UBL), 
                                             //IRSALIYE_YANITI_UBL, IRSALIYE_YANITI (CS-XML), IRSALIYE_UBL, IRSALIYE (CS-XML)
                string belgeFormati = "UBL";  //“HTML” , “PDF” , “UBL”

                byte[] gidenBelgeleriIndirVal = methods.gidenBelgeleriIndir(vergiTcKimlikNo, belgeOidListesi, belgeTuru, belgeFormati);
                
                System.IO.File.WriteAllBytes(@"C:\IndirilenBelgeler\indirilenler.zip", gidenBelgeleriIndirVal);
            }
            catch (Exception exp)
            {

                Console.WriteLine(exp.Message);
            }
        }


        public static void GidenBelgeleriIndirEttn(connectorService methods, string vergiTcKimlikNoParam)
        {

            try
            {
                Console.WriteLine("\n\nGidenBelgeleriIndirEttn");
                string vergiTcKimlikNo = vergiTcKimlikNoParam;
                string[] belgeEttnListesi = new string[] { "19d154d1-9502-4401-9f7f-893142f9b92f", "3be59765-029a-4e5d-8a2b-abd37a652073", "521e892a-6c79-4237-926c-60df448fb8bf", "d8f328e0-a6dc-452b-9435-4c4ef32fe74f" };
                string belgeTuru = "FATURA"; //FATURA (CS-XML),UYGULAMA_YANITI (CS-XML); FATURA_UBL (direk UBL), UYGULAMA_YANITI_UBL (direk UBL), 
                                             //IRSALIYE_YANITI_UBL, IRSALIYE_YANITI (CS-XML), IRSALIYE_UBL, IRSALIYE (CS-XML)
                string belgeFormati = "UBL";  //“HTML” , “PDF” , “UBL”
                byte[] gidBelIndirETTN = methods.gidenBelgeleriIndirEttn(vergiTcKimlikNo, belgeEttnListesi, belgeTuru, belgeFormati);

                System.IO.File.WriteAllBytes(@"C:\Users\osman.cuhadar\Desktop\eFaturaSample\IndirilenBelgeler\" + belgeEttnListesi[0] + ".zip", gidBelIndirETTN);
                Console.WriteLine("Dosyaya yazdırıldı.");
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception'a düştü.");
                Console.WriteLine(exp.Message);
            }

        }


        public static void GidenFaturalariArsiveKaldir(connectorService methods, string vergiTcKimlikNoParam)
        {

            try
            {
                Console.WriteLine("\n\nGidenFaturalariArsiveKaldir");
                string vergiTcKimlikNo = vergiTcKimlikNoParam;
                string[] invoiceEttnListesi = new string[] { "19d154d1-9502-4401-9f7f-893142f9b92f", "3be59765-029a-4e5d-8a2b-abd37a652073", "521e892a-6c79-4237-926c-60df448fb8bf", "d8f328e0-a6dc-452b-9435-4c4ef32fe74f" };

                methods.gidenFaturalariArsiveKaldir(vergiTcKimlikNo, invoiceEttnListesi);
                Console.WriteLine("Arşiv'e alındı.");
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception'a düştü.");
                Console.WriteLine(exp.Message);
            }

        }

        public static void GidenTasinanBelgeleriIndir(connectorService methods, string vergiTcKimlikNoParam)
        {

            try
            {
                Console.WriteLine("\n\nGidenFaturalariArsiveKaldir");
                string vergiTcKimlikNo = vergiTcKimlikNoParam;
                string[] ettnler = new string[] { "19d154d1-9502-4401-9f7f-893142f9b92f", "3be59765-029a-4e5d-8a2b-abd37a652073", "521e892a-6c79-4237-926c-60df448fb8bf", "d8f328e0-a6dc-452b-9435-4c4ef32fe74f" };
                string belgeFormati = "UBL";  //“HTML” , “PDF” , “UBL”

                byte[] gidenTasinanBelgeleriIndirVal = methods.gidenTasinanBelgeleriIndir(vergiTcKimlikNo, ettnler, belgeFormati);

                System.IO.File.WriteAllBytes(@"C:\Users\osman.cuhadar\Desktop\eFaturaSample\IndirilenBelgeler\tasinanBelgeler.zip", gidenTasinanBelgeleriIndirVal);
            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception'a düştü.");
                Console.WriteLine(exp.Message);
            }

        }
    }
}
