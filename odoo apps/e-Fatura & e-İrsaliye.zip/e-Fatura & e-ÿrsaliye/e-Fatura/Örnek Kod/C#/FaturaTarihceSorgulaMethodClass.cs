﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class FaturaTarihceSorgulaMethodClass
    {

        public static void FaturaTarihcesiSorgula(connectorService methods, string vergiTcKimlikNo)
        {
            string ettn = null;
            string faturaYonu = "GIDEN";  // GELEN veya GIDEN değeri alır.
            string vknTckn = vergiTcKimlikNo;
            serviceReturnType[] tarihce = methods.faturaTarihcesiSorgula(ettn, faturaYonu, vknTckn);

            foreach (faturaTarihcesiData item in tarihce)
            {
                Console.WriteLine("\nİlişkili Kayıt ID: " + item.bagliKayitId +     // string
                                  "\nETTN: " + item.faturaEttn +                    // string
                                  "\nİşlem: " + item.islem +                        // short
                                  "\nİşlem Açıklama: " + item.islemAciklama +       // string
                                  "\nİşlem Kanalı: " + item.islemKanali +           // sbyte
                                  "\nİşlem Sonucu: " + item.islemSonucu +           // string
                                  "\nİşlem Zamanı: " + item.islemZamani +           // string
                                  "\nKanal Açıklama: " + item.islemKanaliAciklama +    // string
                                  "\nKullanıcı: " + item.kullanici +                // string
                                  "\nKullanıcı IP: " + item.kullaniciIp +           // string
                                  "\nZarfID: " + item.zarfEttn);                    // string
            }
        }
    }
}
