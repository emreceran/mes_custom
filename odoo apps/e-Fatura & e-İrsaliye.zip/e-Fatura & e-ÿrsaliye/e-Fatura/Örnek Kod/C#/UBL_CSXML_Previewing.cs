﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class UBL_CSXML_Previewing
    {

        public static void UblOnizleme(connectorService methods, string _vergiTcKimlikNo)
        {
            try
            {
                Console.WriteLine("UblOnizleme...");
                string vergiTcKimlikNo = _vergiTcKimlikNo;
                byte[] veri = System.IO.File.ReadAllBytes(@"C:\eFinanseFaturaSample\faturaSample.xml"); //Fatura XML'i okunur.
                string belgeFormati = "PDF";  //HTML, PDF, UBL
                string belgeTuru = "EFATURA"; //EFATURA ve EIRSALIYE değerleri alabilir.

                byte[] UBLOnizleme = methods.ublOnizleme(vergiTcKimlikNo, veri, belgeFormati,belgeTuru);

                System.IO.File.WriteAllBytes(@"C:\eFinanseFaturaSample\faturaSample.pdf", UBLOnizleme);
                Console.WriteLine("Yazdırıldı.");
            }
            catch (Exception ex)
            {

                Console.WriteLine("\nException: \n" + ex.Message);
            }

        }


        public static void CSXMOnizleme(connectorService methods, string _vergiTcKimlikNo)
        {
            try
            {
                Console.WriteLine("CSXMOnizleme...");
                string vergiTcKimlikNo = _vergiTcKimlikNo; // ZORUNLU!!!
                string belgeVersiyon = "3.0";  // ZORUNLU!!! "1.0", "2.0", "3.0" değerleri alabilir.
                byte[] veri = System.IO.File.ReadAllBytes(@"C:\eFinanseFaturaSample\faturaSample.xml"); //ZORUNLU!!! fatura XML'i okunur.
                string belgeFormati = "PDF";  //ZORUNLU!!! HTML, PDF, UBL
                string xsltAdi = ""; // OPSİYONEL!!! Boşsa, Varsayılan XSLT kullanılır. 
                string belgeTuru = "EFATURA"; // ZORUNLU!!! EFATURA ve EIRSALIYE değerleri alabilir.

                byte[] CSXMLOnizleme = methods.csXmlOnizleme(vergiTcKimlikNo,belgeVersiyon, veri, belgeFormati, xsltAdi, belgeTuru);

                System.IO.File.WriteAllBytes(@"C:\eFinanseFaturaSample\faturaSample.pdf", CSXMLOnizleme);
                Console.WriteLine("Yazdırıldı.");
            }
            catch (Exception ex)
            {

                Console.WriteLine("\nException: \n" + ex.Message);
            }

        }
    }
}
