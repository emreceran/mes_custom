﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class KontorStatus
    {
        public static void KontorBilgisiGetir(connectorService methods, string _vergiTcKimlikNo)
        {
            try
            {
                Console.WriteLine("KontorBilgisiGetir...\n");
                string vergiTcKimlikNo = _vergiTcKimlikNo;

                string kontorTipiStr = "1";   // e-Fatura: 1, e-Arşiv: 5, e-Defter: 2, e-İrsaliye: 7
                string kontorBirimiStr = "1"; // e-Fatura: 1, e-Arşiv: 1, e-Defter: 3, e-İrsaliye: 1
                kalanKontorBilgisi kalanKontorBilgisiResponse = methods.kontorBilgisiGetir(vergiTcKimlikNo, kontorTipiStr, kontorBirimiStr);

                Console.WriteLine("vknTckn: " + kalanKontorBilgisiResponse.vknTckn +
                                  "\nkontorTipi: " + kalanKontorBilgisiResponse.kontorTipi +
                                  "\nkontorBirimi: " + kalanKontorBilgisiResponse.kontorBirimi +
                                  "\ntoplamAlinan: " + kalanKontorBilgisiResponse.toplamAlinan +
                                  "\nkalan: " + kalanKontorBilgisiResponse.kalan +
                                  "\nlimitAsimMiktari: " + kalanKontorBilgisiResponse.limitAsimMiktari +"\n");               
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nException: \n" + ex.Message);
            }

        }
    }
}
