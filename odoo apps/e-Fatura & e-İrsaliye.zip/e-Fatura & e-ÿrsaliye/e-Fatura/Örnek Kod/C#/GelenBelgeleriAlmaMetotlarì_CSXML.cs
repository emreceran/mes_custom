﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class GelenBelgeleriAlmaMetotları_CSXML
    {
        private static string pathStr = @"C:\TEMP";

        //dateStr değişkeni, Log Dosyası isimlendirmesi için kullanılmaktadır.
        private static string dateStr = DateTime.Now.ToString("yyyyMMddHHmmss");

        private static void pathOlustur(string pathStr)
        {
            if (!System.IO.Directory.Exists(pathStr))
            {
                System.IO.Directory.CreateDirectory(pathStr);

            }
        }

        public static void GelenBelgeleriAlExt(connectorService methods, string vergiTcKimlikNoParam)
        {
            pathOlustur(pathStr);
            string[] ettnler = new string[100]; // bir defada 100 belge alınabilmektedir

            gelenBelgeParametreleri parametreler = new gelenBelgeParametreleri();
            parametreler.vergiTcKimlikNo = vergiTcKimlikNoParam;
            parametreler.belgeTuru = "FATURA";       // "FATURA" veya "UYGULAMA_YANITI" değerleri alabilir. 
            parametreler.belgeFormati = "UBL";     // "UBL", "HTML", "PDF" değerlerini alabilir. gelenBelgeleriAlExt, gelenBelgeleriIndir gibi indirme metotlarında kullanılır. listelemede kullanılamaz.
            parametreler.donusTipiVersiyon = "2.0";  // "1.0" ise belge; "2.0" ise belgev2 değeri alır.
            parametreler.belgeVersiyon = "3.0";    // "1.0", "2.0", "3.0" değerlerini alabilir. gelenBelgeleriAlExt metotunda aktif olarak kullanılmaktadır.
            parametreler.erpKodu = "ERP1";       // eFinans tarafından ERP bazlı oluşturulan statik bir değerdir. 

            /* “sonAlinanBelgeSiraNumarasi” parametresi ile birlikte 
            “gelisTarihiBaslangic“, “gelisTarihiBitis “, “onayDurum “,  “subeKodu“ ve “alanEtiket“ parametrelerinden 
            bir ya da birkaçı girildiği taktirde sistem parametreleri hatalı kabul edecek 
            ve işlemi gerçekleştirmeyecektir. */

            parametreler.sonAlinanBelgeSiraNumarasi = "0";  // Belgeleri sırasıyla çekmeyi sağlar.

            /* parametreler.alanEtiket parametresi: Firmanın birden fazla etiketinin mevcut olduğu durumlarda 
            sadece belirli etiketlerine gelen faturaları listelemek için bu alan doldurulabilir.
            Bu alan hiç kullanılmadığında bütün etiketlere gelen faturalar listelenmektedir. */

            //parametreler.alanEtiket = defaultpk;

            /*Belirli bir onay durumunda olan faturaların alınması için kullanılır. 
             “ONAYBEKLEYEN”, “ONAYLANAN”, “HEPSI” değerlerinden birini alabilir. 
             Boş bırakılması durumunda sadece “ONAYLANAN” faturalar listelenecektir. */

            //parametreler.onayDurum = "HEPSI"; 

            //parametreler.ettn = new string[] { "fa7f449f-9c88-44c7-b945-c7465e387e28" }; //Yalnızca belirtilen ettn'li faturaları almayı sağlar.

            //parametreler.gelisTarihiBaslangic = "20131220000000000";      // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.gelisTarihiBitis = "20140923000000000";          // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.faturaTarihiBaslangic = "20131220000000000";     // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.faturaTarihiBitis = "20140923000000000";         // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 

            //parametreler.gonderenEtiket;      // pasiftir. Kullanılmasına gerek bulunmamaktadır.
            //parametreler.subeKodu;            // pasiftir. Kullanılmasına gerek bulunmamaktadır.
            //parametreler.entegrasyonHedefi;   // pasiftir. Kullanılmasına gerek bulunmamaktadır.

            serviceReturnType[] gelenBelgeleriListeleExtObj = methods.gelenBelgeleriAlExt(parametreler);

            /*
            
            // donusTipiVersiyon = 1.0 ise serviceReturnType belge'ye cast edilir.

            foreach (belge gelenBelgeleriAlValue in gelenBelgeleriListeleExtObj)
            {
                
                string belgeNo = gelenBelgeleriAlValue.belgeNo;
                string belgeSiraNo = gelenBelgeleriAlValue.belgeSiraNo;
                string belgeTarihi = gelenBelgeleriAlValue.belgeTarihi;
                string belgeTuruRes = gelenBelgeleriAlValue.belgeTuru;
                string belgeVerisi = gelenBelgeleriAlValue.belgeVerisi;  
                string ETTN = gelenBelgeleriAlValue.ettn;
                string gonderenEtiket = gelenBelgeleriAlValue.gonderenEtiket;
                string gonderenVknTckn = gelenBelgeleriAlValue.gonderenVknTckn;

                Console.WriteLine("\nBelgeNo: " + belgeNo +
                                  "\nBelgeSıraNo: " + belgeSiraNo +
                                  "\nBelge Tarihi: " + belgeTarihi +
                                  "\nBelge Türü: " + belgeTuruRes +
                                  //"\nBelge Verisi: " + belgeVerisi+
                                  "\nETTN: " + ETTN +
                                  "\nGönderen Etiket: " + gonderenEtiket +
                                  "\nGönderen VKN_TCKN: " + gonderenVknTckn);
            }
            */



            // donusTipiVersiyon = 2.0 ise serviceReturnType belgev2'ye cast edilir.
            foreach (belgev2 item in gelenBelgeleriListeleExtObj)
            {

                string alanEtiketi = item.alanEtiket;
                string aliciUnvan = item.aliciUnvan;
                string belgeNo = item.belgeNo;
                string belgeSiraNo = item.belgeSiraNo;
                string belgeTarihi = item.belgeTarihi;
                string belgeTuru = item.belgeTuru;
                string ETTN = item.ettn;
                string gonderenEtiket = item.gonderenEtiket;
                string gonderenVknTckn = item.gonderenVknTckn;
                string saticiUnvan = item.saticiUnvan;
                string zarfId = item.zarfId;
                string belgeVersiyon = item.belgeVersiyon;
                string belgeVerisi = item.belgeVerisi;
                byte[] belgeXmlZipped = item.belgeXmlZipped;
                byte[] zarfVerisi = item.zarfVerisi;      
                string zarfXml = item.zarfXml;    
                belgev2Entry[] ekBilgiler = item.ekBilgiler;

                foreach (belgev2Entry itemEkInf in ekBilgiler)
                {
                    Console.WriteLine(itemEkInf.key + ": " + itemEkInf.value);
                }

                //string subeKodu = item.subeKodu;         // Şimdilik pasiftir

                Console.WriteLine("\nAlıcı Ünvan: " + aliciUnvan +
                                  "\nSatıcı Ünvan: " + saticiUnvan +
                                  "\nBelge Versiyon: " + belgeVersiyon +
                                  "\nAlan Etiket: " + alanEtiketi +
                                  "\nGönderen Etiket: " + gonderenEtiket +
                                  "\nGönderen VKN_TCKN: " + gonderenVknTckn +
                                  "\nBelge Türü: " + belgeTuru +
                                  //"\nŞube Kodu: " + subeKodu + // pasiftir.
                                  "\nZarfID: " + zarfId +
                                  "\nZarfXML: " + zarfXml + 
                                  "\nETTN: " + ETTN +
                                  "\nBelge No: " + belgeNo +
                                  "\nBelge Sıra No: " + belgeSiraNo +
                                  "\nBelge Tarihi: " + belgeTarihi +
                                  "\nBelge Verisi: " + belgeVerisi
                                  );

              
                string[] hepsininAlayi = {"\nAlıcı Ünvan: " + aliciUnvan +
                                  "\nSatıcı Ünvan: " + saticiUnvan +
                                  "\nAlan Etiket: " + alanEtiketi +
                                  "\nGönderen Etiket: " + gonderenEtiket +
                                  "\nGönderen VKN_TCKN: " + gonderenVknTckn +
                                  "\nBelge Türü: " + belgeTuru +
                                  "\nZarfID: " + zarfId +
                                  "\nETTN: " + ETTN +
                                  "\nBelge No: " + belgeNo +
                                  "\nBelge Sıra No: " + belgeSiraNo +
                                  "\nBelge Tarihi: " + belgeTarihi
                                };
                System.IO.File.AppendAllLines(pathStr + "\\LogFile_" + dateStr + ".txt", hepsininAlayi);
            }

            //Console.WriteLine("\nToplam: " + sayac + " EFatura");
            
        }
    }
}
