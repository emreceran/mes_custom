﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System.Security.Cryptography;
using eFinansPortalTestEFaturaConsoleWS.Login;
using System.Net;

namespace eFinansPortalTestEFaturaConsoleWS
{
    class Program
    {
        
      

        static void Main(string[] args)
        {
            Login.userService login = new Login.userService();
            PortalTestEFatura.connectorService methods = new PortalTestEFatura.connectorService();
            try
            {
                
                

                login.CookieContainer = new System.Net.CookieContainer();
                methods.CookieContainer = login.CookieContainer;
                
                string VKN_TCKN = "VKN_TCKN";

                string userId = "UserID";
                string password = "Password";
                

                login.wsLogin(userId, password, "tr");

                Console.WriteLine("###################");

				/*
				e-Fatura Kayıtlı Kullanıcılar aşağıdaki Methodlardan biri yardımıyla çekilebilir.
				Günde 1 defa çekmek yeterlidir.
				*/
                KayitliKullaniciListeleExtended(methods);
				//KayitliKullaniciListeleExtendedVknTckn(methods);
				//KayitliKullaniciListeleExtendedTime(methods);
				
                
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            finally
            {
                login.logout();
            }

       
            Console.WriteLine("Bitti...");
            Console.ReadLine();

        }


        public static void KayitliKullaniciListeleExtended(connectorService methods)
        {
            Console.WriteLine("KayitliKullaniciListeleExtended...");
            string urun = "EFATURA"; //EFATURA, EIRSALIYE değerleri alabilir.
            int gecmisEklensin = 1;
            bool gecmisEklensinSpecified = true; // C#'a özeldir.
            byte[] kayitliMukellefListesi = methods.kayitliKullaniciListeleExtended(urun, gecmisEklensin, gecmisEklensinSpecified);
            string dateStr = DateTime.Now.ToString("yyyyMMddHHmmss");
            string pathStr = @"C:\Portaltest_kayitliKullanicilar";
            if (!System.IO.Directory.Exists(pathStr))
            {
                System.IO.Directory.CreateDirectory(pathStr);
                System.IO.File.WriteAllBytes(@"C:\Portaltest_kayitliKullanicilar\Portaltest_" + dateStr + "_"+ urun + "_kayitliMukellefler.zip", kayitliMukellefListesi);
            }
            else
            {
                System.IO.File.WriteAllBytes(@"C:\Portaltest_kayitliKullanicilar\Portaltest_" + dateStr + "_" + urun + "_kayitliMukellefler.zip", kayitliMukellefListesi);
            }
            
            Console.WriteLine("C:\\Portaltest_kayitliKullanicilar dizinine yazdırılmıştır.");

            Process.Start(pathStr);
        }

        //Belirli bir kayıt tarihinden sonraki e-Fatura ve e-Irsaliye Mükellef Listesi  zip olarak elde edilebilir.
        public static void KayitliKullaniciListeleExtendedVknTckn(connectorService methods)
        {
            Console.WriteLine("KayitliKullaniciListeleExtendedVknTckn...");
            string vknTckn = null;
            string urun = "EFATURA";  //EFATURA, EIRSALIYE değerleri alabilir.
            byte[] kayitliMukellefListesi = methods.kayitliKullaniciListeleExtendedVknTckn(vknTckn,urun);

            string dateStr = DateTime.Now.ToString("yyyyMMddHHmmss");
            string pathStr = @"C:\Portaltest_kayitliKullanicilar";
            if (!System.IO.Directory.Exists(pathStr))
            {
                System.IO.Directory.CreateDirectory(pathStr);
                System.IO.File.WriteAllBytes(@"C:\Portaltest_kayitliKullanicilar\Portaltest_" + dateStr + "_kayitliMukellefler.zip", kayitliMukellefListesi);
            }
            else
            {
                System.IO.File.WriteAllBytes(@"C:\Portaltest_kayitliKullanicilar\Portaltest_" + dateStr + "_kayitliMukellefler.zip", kayitliMukellefListesi);
            }

            Console.WriteLine("C:\\Portaltest_kayitliKullanicilar dizinine yazdırılmıştır.");

            Process.Start(pathStr);
        }

        //Belirli bir kayıt tarihinden sonraki e-Fatura ve e-Irsaliye Mükellef Listesi  zip olarak elde edilebilir.
        public static void KayitliKullaniciListeleExtendedTime(connectorService methods)
        {
            Console.WriteLine("KayitliKullaniciListeleExtendedTime...");
            string kayitZamani = ""; //YYYYAAGG
            string urun = "EFATURA";  //EFATURA, EIRSALIYE değerleri alabilir.
            int gecmisEklensin = 1;
            bool gecmisEklensinSpecified = true;
            byte[] kayitliMukellefListesi = methods.kayitliKullaniciListeleExtendedTime(kayitZamani, urun, gecmisEklensin, gecmisEklensinSpecified);

            string dateStr = DateTime.Now.ToString("yyyyMMddHHmmss");
            string pathStr = @"C:\Portaltest_kayitliKullanicilar";
            if (!System.IO.Directory.Exists(pathStr))
            {
                System.IO.Directory.CreateDirectory(pathStr);
                System.IO.File.WriteAllBytes(@"C:\Portaltest_kayitliKullanicilar\Portaltest_" + dateStr + "_kayitliMukellefler.zip", kayitliMukellefListesi);
            }
            else
            {
                System.IO.File.WriteAllBytes(@"C:\Portaltest_kayitliKullanicilar\Portaltest_" + dateStr + "_kayitliMukellefler.zip", kayitliMukellefListesi);
            }

            Console.WriteLine("C:\\Portaltest_kayitliKullanicilar dizinine yazdırılmıştır.");

            Process.Start(pathStr);
        }

    }
}





