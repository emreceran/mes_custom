﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class GidenBelgeEkleriAlClass
    {
        public static void GidenBelgeEkleriAl(connectorService methods, string belgeNoParam, string vKN_TCKN)
        {
            string uuid = null;
            string vknTckn = vKN_TCKN;
            string belgeTuru = null;
            byte[] gidenBelgeEkleriVariable = methods.gidenBelgeEkleriAl(uuid, vknTckn, belgeTuru);
            System.IO.File.WriteAllBytes("", gidenBelgeEkleriVariable);
        }
    }
}
