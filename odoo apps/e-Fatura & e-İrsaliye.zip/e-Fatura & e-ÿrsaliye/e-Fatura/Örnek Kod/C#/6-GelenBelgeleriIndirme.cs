﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class GelenBelgeleriIndirme
    {
        private static string pathStr = @"C:\TEMP";

        //dateStr değişkeni, Log Dosyası isimlendirmesi için kullanılmaktadır.
        private static string dateStr = DateTime.Now.ToString("yyyyMMddHHmmss");

        private static void pathOlustur(string pathStr)
        {
            if (!System.IO.Directory.Exists(pathStr))
            {
                System.IO.Directory.CreateDirectory(pathStr);
            }
        }

        // bir defada en fazla 100 fatura indirilebilir.
        public static void GelenBelgeleriIndirExt(connectorService methods, string vergiTcKimlikNoParam)
        {
            pathOlustur(pathStr);

            gelenBelgeParametreleri parametreler = new gelenBelgeParametreleri();

            parametreler.vergiTcKimlikNo = vergiTcKimlikNoParam;
            parametreler.belgeTuru = "FATURA";       // "FATURA" veya "UYGULAMA_YANITI" değerleri alabilir. 
            parametreler.belgeFormati = "UBL";     // "UBL", "HTML", "PDF" değerlerini alabilir. gelenBelgeleriAlExt, gelenBelgeleriIndir gibi indirme metotlarında kullanılır. listelemede kullanılamaz.
            //parametreler.donusTipiVersiyon = "2.0";  // "1.0" ise belge; "2.0" ise belgev2 değeri alır. Listeleme metotunda kullanılır.
            //parametreler.belgeVersiyon = "3.0";    // "1.0", "2.0", "3.0" değerlerini alabilir. gelenBelgeleriAlExt metotunda aktif olarak kullanılmaktadır.
            parametreler.erpKodu = "ERP1";       // eFinans tarafından ERP bazlı oluşturulan statik bir değerdir. 

            /* “sonAlinanBelgeSiraNumarasi” parametresi ile birlikte 
            “gelisTarihiBaslangic“, “gelisTarihiBitis “, “onayDurum “,  “subeKodu“ ve “alanEtiket“ parametrelerinden 
            bir ya da birkaçı girildiği taktirde sistem parametreleri hatalı kabul edecek 
            ve işlemi gerçekleştirmeyecektir. */

            parametreler.sonAlinanBelgeSiraNumarasi = "0";  // Belgeleri sırasıyla çekmeyi sağlar.

            /* parametreler.alanEtiket parametresi: Firmanın birden fazla etiketinin mevcut olduğu durumlarda 
            sadece belirli etiketlerine gelen faturaları indirmek için bu alan doldurulabilir.
            Bu alan hiç kullanılmadığında bütün etiketlere gelen faturalar indirilmektedir. */

            //parametreler.alanEtiket = defaultpk;

            /*Belirli bir onay durumunda olan faturaların listelenmesi için kullanılır. 
             “ONAYBEKLEYEN”, “ONAYLANAN”, “HEPSI” değerlerinden birini alabilir. 
             Boş bırakılması durumunda sadece “ONAYLANAN” faturalar listelenecektir. */

            //parametreler.onayDurum = "HEPSI"; 

            //parametreler.ettn = new string[] { "fa7f449f-9c88-44c7-b945-c7465e387e28" }; //Yalnızca belirtilen ettn'li faturaları indirir.

            //parametreler.gelisTarihiBaslangic = "20131220000000000";      // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.gelisTarihiBitis = "20140923000000000";          // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.faturaTarihiBaslangic = "20131220000000000";     // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.faturaTarihiBitis = "20140923000000000";         // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 

            //parametreler.gonderenEtiket;      // pasiftir. Kullanılmasına gerek bulunmamaktadır.
            //parametreler.subeKodu;            // pasiftir. Kullanılmasına gerek bulunmamaktadır.
            //parametreler.entegrasyonHedefi;   // pasiftir. Kullanılmasına gerek bulunmamaktadır.

            byte[] gelenBelgeler = methods.gelenBelgeleriIndirExt(parametreler);

            System.IO.File.WriteAllBytes(pathStr + "GelenUBLler_"+ dateStr + ".zip", gelenBelgeler);

        }

        // bir defada en fazla 100 fatura indirilebilir.
        public static void GelenBelgeleriIndir(connectorService methods, string vergiTcKimlikNoParam)
        {
            pathOlustur(pathStr);

            string vergiTcKimlikNo = vergiTcKimlikNoParam;
            string[] ettnler = new string[] { "291DB9EC-4FC4-4F7E-BDD2-C5C54F62A635", "3e60aad6-48cc-4f76-a20c-5fc892d1a837" };
            string belgeTuru = "FATURA";        // "FATURA" ve "UYGULAMA_YANITI"
            string belgeFormati = "UBL";        // "HTML", "PDF", "UBL"
            byte[] gelenBelgeleriIndirValue = methods.gelenBelgeleriIndir(vergiTcKimlikNo, ettnler, belgeTuru, belgeFormati);

            System.IO.File.WriteAllBytes(pathStr + "GelenUBLler_" + dateStr + ".zip", gelenBelgeleriIndirValue);
        }
    }
}
