﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System.Security.Cryptography;
using eFinansPortalTestEFaturaConsoleWS.Login;
using System.Net;

namespace eFinansPortalTestEFaturaConsoleWS
{
    class Program
    {
        //Aynı durum sorgulamalarını tekrar tekrar yazdırmamak için flag ve tempFlag değişkenleri oluşturulmuştur.
        private static int flag = 0;
        private static int tempFlag = 0;

        //Giriş parametrelerini tekrar tekrar yazdırmamak için tempFlagBool değişkeni kullanılmıştır.
        private static bool tempFlagBool = false;

        //dateStr değişkeni, Log Dosyası isimlendirmesi için kullanılmaktadır.
        private static string dateStr = DateTime.Now.ToString("yyyyMMddHHmmss");
      

        static void Main(string[] args)
        {
            Login.userService login = new Login.userService();
            PortalTestEFatura.connectorService methods = new PortalTestEFatura.connectorService();
            try
            {
                
                

                login.CookieContainer = new System.Net.CookieContainer();
                methods.CookieContainer = login.CookieContainer;
                
                string VKN_TCKN = "VKN_TCKN";

                string userId = "UserID";
                string password = "Password";
                

       

                login.wsLogin(userId, password, "tr");


                Console.WriteLine("###################");

				//Durum Sorgulama ile ilgili aşağıdaki Methodlardan birisi kullanılabilir.
                GidenBelgeDurumSorgulaExt(methods, VKN_TCKN);
				//GidenBelgeDurumSorgula(methods, VKN_TCKN);
				//GidenBelgeDurumSorgulaEttn(methods, VKN_TCKN);
				//GidenBelgeDurumSorgulaYerelBelgeNo(methods, VKN_TCKN);
				//CokluGidenBelgeDurumSorgula(methods, VKN_TCKN);
                
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            finally
            {
                login.logout();
            }

       
            Console.WriteLine("Bitti...");
            Console.ReadLine();

        }
		

        /*
        GidenBelgeDurumSorgulaExt metotu: belgeNoTipi input parametresinde belirtilen (YEREL,OID,ETTN) kritere göre 
        belgeNo input parametresine değer alır ve gönderilen faturanın durumunu sorgular. 
        */
        public static void GidenBelgeDurumSorgulaExt(connectorService methods, string belgeNoParam, string vKN_TCKN)
        {
            if (tempFlagBool != true)
            {
                Console.WriteLine("\n\nGidenBelgeDurumSorgulaExt\n**************************");
                tempFlagBool = true;
            }


            string pathStr = @"C:\TEMP";
            string durumKontrolu = "";

            try
            {
                string vergiTcKimlikNo = vKN_TCKN;
                gidenBelgeDurumParametreleri parametreler = new gidenBelgeDurumParametreleri();

                //parametreler.belgeNoList = null;  //Sadece OID alabiliyor. 
                parametreler.belgeNoTipi = "OID";  //Karakter (YEREL,OID,ETTN) (Varsayılan YEREL)
                parametreler.belgeNo = belgeNoParam;  // belgeNoTipi:OID ise messageOid; ETTN ise ETTN; YEREL ise Yerel Belge No girilir.
                //parametreler.belgeTuru = "FATURA";  //OPSİYONEL. FATURA (CSXML içindir),  FATURA_UBL, UYGULAMA_YANITI (CSXML içindir), UYGULAMA_YANITI_UBL değerlerini alabilir.
                parametreler.donusTipiVersiyon = "5.0"; // serviceReturnType: "1.0" ise gidenBelgeDurum, "2.0" ise gidenBelgeDurumv2 , "3.0" ise gidenBelgeDurumv3 , "4.0" gidenBelgeDurumv4, "5.0" gidenBelgeDurumv5 'e cast edilmelidir.  

                serviceReturnType gidenBelgeSorgulaExt = methods.gidenBelgeDurumSorgulaExt(vergiTcKimlikNo, parametreler);

                gidenBelgeDurumv5 gidenBelgeDurumu = (gidenBelgeDurumv5)gidenBelgeSorgulaExt;

                string durumAciklamaStr = "";
                string durumAciklama = gidenBelgeDurumu.aciklama;  // işleme hatası alındığını gösteren durum = 2 'de açıklama geliyor.
                string alimTarihi = gidenBelgeDurumu.alimTarihi;
                string belgeNo = gidenBelgeDurumu.belgeNo;
                int durumKodu = gidenBelgeDurumu.durum;
                string ettnDonen = gidenBelgeDurumu.ettn;
                string gonderimCevabiDetayi = gidenBelgeDurumu.gonderimCevabiDetayi;
                int gonderimCevabiKodu = gidenBelgeDurumu.gonderimCevabiKodu;
                int gonderimDurumu = gidenBelgeDurumu.gonderimDurumu;
                string gonderimTarihi = gidenBelgeDurumu.gonderimTarihi;
                string olusturulmaTarihi = gidenBelgeDurumu.olusturulmaTarihi;
                string yanitDetayi = gidenBelgeDurumu.yanitDetayi;
                int yanitDurumu = gidenBelgeDurumu.yanitDurumu;
                string yanitTarihi = gidenBelgeDurumu.yanitTarihi;
                bool ulastiMi = gidenBelgeDurumu.ulastiMi;
                bool yenidenGonderilebilirMi = gidenBelgeDurumu.yenidenGonderilebilirMi;
                string gtbFiiliIhracatTarihi = gidenBelgeDurumu.gtbFiiliIhracatTarihi; //İhracat Faturalarına özeldir.
                string gtbGcbTescilNo = gidenBelgeDurumu.gtbGcbTescilNo;  //İhracat Faturalarına özeldir.
                string gtbRefNo = gidenBelgeDurumu.gtbRefNo;  //İhracat Faturalarına özeldir.
                string yanitEttn = gidenBelgeDurumu.yanitEttn; //İrsaliye'ye özeldir.
                string yanitVerilenBelgeEttn = gidenBelgeDurumu.yanitVerilenBelgeEttn; //İrsaliye'ye özeldir.
                string yerelBelgeOid = gidenBelgeDurumu.yerelBelgeOid;

                if (durumKodu == 1) // Fatura eFinans'a ulaşmıştır.
                {
                    //Console.WriteLine("\n*****durumKodu == 1 kontrolü");
                    durumKontrolu += "*****durumKodu == 1 kontrolü\n";
                    durumAciklamaStr = "Alındı Durumudur.\nDurum Kodu 2 veya 3 olana kadar beklenmelidir.\n";
                    //flag = 1;
                }
                if (durumKodu == 2)
                {
                    //Console.WriteLine("\n*****durumKodu == 2 kontrolü");
                    durumKontrolu += "*****durumKodu == 2 kontrolü\n";
                    durumAciklamaStr = "Fatura İşleme hatasıdır.\nHata nedenine göre düzeltip yeniden gönderiniz.\n";
                    //flag = 2;
                }
                if (durumKodu == 3)
                {
                    //Console.WriteLine("\n*****durumKodu == 3 kontrolü");
                    durumKontrolu += "*****durumKodu == 3 kontrolü\n";
                    durumAciklamaStr = "Fatura Başarıyla İşlenmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";
                    //flag = 3;
                    if (gonderimDurumu == -2)
                    {
                        //Console.WriteLine("*****gonderimDurumu == -2 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == -2 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi. İptal edildi, gönderilmeyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 4;
                    }
                    if (gonderimDurumu == -1)
                    {
                        //Console.WriteLine("*****gonderimDurumu == -1 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == -1 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderim kuyruğuna eklendi.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 5;
                    }
                    if (gonderimDurumu == 0)
                    {
                        //Console.WriteLine("*****gonderimDurumu == 0 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 0 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi, sistem gönderim işlemini yeniden deneyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 6;
                    }
                    if (gonderimDurumu == 1)
                    {
                        //Console.WriteLine("*****gonderimDurumu == 1 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 1 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderilecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 7;
                    }
                    if (gonderimDurumu == 2)  //Fatura GIB'tedir.
                    {
                        //Console.WriteLine("*****gonderimDurumu == 2 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 2 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderilmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 8;
                    }
                    if (gonderimDurumu == 3)
                    {
                        //Console.WriteLine("*****gonderimDurumu == 3 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 3 kontrolü\n";
                        //flag = 9;
                        if (gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü\n";
                            durumAciklamaStr = "Fatura gönderiminde hata bulunmuştur. Hata mesajı aynı metodun gonderimCevabiDetayi parametresinde görüntülenebilir. Hata kodlarının açıklamaları kılavuzdadır.";
                            //flag = 10;
                        }
                        if (gonderimCevabiKodu == 1200)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1200 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1200 kontrolü\n";
                            durumAciklamaStr = "Fatura GIB'le Alıcı arasındadır.";
                            //flag = 11;
                        }

                        if (gonderimCevabiKodu == 1210)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1210 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1210 kontrolü\n";
                            durumAciklamaStr = "GİB, alıcıya zarfı iletmeye çalışmış ancak iletememiştir. Durumun alıcıya iletilmesi faydalı olacaktır. Ancak bu durum GİB ile alıcı firmanın sistemleri arasındaki bağlantının geçici olarak kopmasından kaynaklanıyor olabilir. GİB zarfı toplamda 4 defa daha belirli aralıklarla göndermeyi deneyecektir. Bu durumda fatura yeniden gönderilmez, durumun değişmesi beklenir. Eğer zarf alıcıya başarıyla iletilirse zarfın durumu 1220, tüm denemeler sonrasında iletilemezse 1215 olur.";
                            durumAciklamaStr += "\n1220 durumunda alıcıdan yeni bir sistem yanıtının gelmesi beklenir. ";
                            //flag = 12;
                        }

                        if (gonderimCevabiKodu == 1215)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1215 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1215 kontrolü\n";
                            durumAciklamaStr = "GİB, alıcıya zarfı ilk gönderim dahil 5 defa göndermeye çalışmış ancak hiçbiri başarılı olmamıştır. Alıcıya bilgi verilmelidir. Bu durumdaki fatura aynı fatura numarasıyla farklı bir zarfla yeniden gönderilebilir.";
                            durumAciklamaStr += "\nbelgeTekrarGonder\nbelgeTekrarGonderBelgeOid\nbelgeTekrarGonderYerelBelgeNo\n metotlarından biri kullanılabilir.";
                            //flag = 13;
                        }

                        if (gonderimCevabiKodu == 1220)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1220 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1220 kontrolü\n";
                            durumAciklamaStr = "GİB, alıcıya zarfı başarıyla iletmiş ancak alıcıdan henüz sistem yanıtı gelmemiştir. Alıcıdan başarısız sistem yanıtı gelene kadar fatura alıcıya iletilmiş sayılmaktadır.  Bu durumda fatura yeniden gönderilmez, alıcıdan sistem yanıtının gelmesi beklenir.";
                            //flag = 14;
                        }

                        if (gonderimCevabiKodu == 1230)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1230 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1230 kontrolü\n";
                            durumAciklamaStr = "Alıcıdan GİB'e, zarfın sistem yanıtı başarısız olarak gelmiştir. Bu durumda fatura iletilmiş sayılmamaktadır. Bu durumdaki fatura aynı fatura numarasıyla farklı bir zarfla yeniden gönderilebilir.";
                            durumAciklamaStr += "\nbelgeTekrarGonder\nbelgeTekrarGonderBelgeOid\nbelgeTekrarGonderYerelBelgeNo\n metotlarından biri kullanılabilir.";
                            //flag = 15;
                        }
                    }
                    if (gonderimDurumu == 4) //Fatura alıcıdadır.
                    {
                        //Console.WriteLine("*****gonderimDurumu == 4 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 4 kontrolü\n";
                        //flag = 16;
                        if (gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300 kontrolü\n";
                            durumAciklamaStr = "Fatura Alıcıya ulaşmıştır.";
                            //flag = 17;

                            if (yanitDurumu == -1)
                            {
                                //Console.WriteLine("*****yanitDurumu == -1 kontrolü");
                                durumKontrolu += "*****yanitDurumu == -1 kontrolü\n";
                                durumAciklamaStr = "Temel Faturadır. Karşıdan yanıt beklenmez.";
                                //flag = 18;
                            }
                            if (yanitDurumu == 0)
                            {
                                //Console.WriteLine("*****yanitDurumu == 0 kontrolü");
                                durumKontrolu += "*****yanitDurumu == 0 kontrolü\n";
                                durumAciklamaStr = "Ticari Faturadır. Karşıdan yanıt beklenmektedir.";
                                //flag = 19;
                            }
                            if (yanitDurumu == 1)
                            {
                                //Console.WriteLine("*****yanitDurumu == 1 kontrolü");
                                durumKontrolu += "*****yanitDurumu == 1 kontrolü\n";
                                durumAciklamaStr = "Ticari Faturadır. Red Uygulama Yanıtı Alınmıştır.";
                                //flag = 20;
                            }
                            if (yanitDurumu == 2)
                            {
                                //Console.WriteLine("yanitDurumu == 2 kontrolü");
                                durumKontrolu += "*****yanitDurumu == 2 kontrolü\n";
                                durumAciklamaStr = "Ticari Faturadır. Kabul Uygulama Yanıtı Alınmıştır.";
                                //flag = 21;
                            }
                        }

                    }
                }

                if (tempFlagBool == false)
                {
                    Console.WriteLine("\nGiriş Parametreleri: \n*********************" +
                                      "\nBelgeNo: " + parametreler.belgeNo +
                                      "\nBelgeNo Tipi: " + parametreler.belgeNoTipi +
                                      "\nBelge Türü: " + parametreler.belgeTuru +
                                      "\nDönüş Tipi Versiyon: " + parametreler.donusTipiVersiyon);
                    tempFlagBool = true;
                    Process.Start(pathStr);
                }

                flag = durumKodu + gonderimDurumu + gonderimCevabiKodu + yanitDurumu;
                if (flag != tempFlag)
                {
                    Console.WriteLine("\nDurum Kodu Açıklama: \n" + durumKontrolu + "\n" + durumAciklamaStr +
                                      "\nDurum Açıklama: " + durumAciklama +
                                      "\nDurum Kodu: " + durumKodu +
                                      "\nGönderim Durumu: " + gonderimDurumu +
                                      "\nGönderim Cevabı Kodu: " + gonderimCevabiKodu +
                                      "\nGönderim Cevabı Detayı: " + gonderimCevabiDetayi +
                                      "\nYanıt Durumu: " + yanitDurumu +
                                      "\nYanıt Detayı: " + yanitDetayi +
                                      "\nUlaştı Mı?: " + ulastiMi +
                                      "\nYeniden Gönderilebilir Mi?: " + yenidenGonderilebilirMi +
                                      "\nBelgeNo (Yerel Belge No): " + belgeNo +
                                      "\nETTN(UUID): " + ettnDonen +
                                      "\nAlım Tarihi (eFinans'a Ulaşma Tarihi): " + alimTarihi +
                                      "\nOluşturulma Tarihi: " + olusturulmaTarihi +
                                      "\nGönderim Tarihi: " + gonderimTarihi +
                                      "\nYanıt Tarihi: " + yanitTarihi +
                                      "\nyanitEttn: " + yanitEttn +      // İrsaliye için geçerlidir.
                                      "\nyanitVerilenBelgeEttn: " + yanitVerilenBelgeEttn// İrsaliye için geçerlidir.
                                      );  


                    string[] hepsininAlayi = {"\n\n---------------------------------\nGidenBelgeDurumSorgulaExt\n***************************"+
                                  "\nDurum Kodu Açıklama: \n" + durumKontrolu + durumAciklamaStr +
                                  "\nDurum Açıklama: " + durumAciklama +
                                  "\nDurum Kodu: " + durumKodu +
                                  "\nGönderim Durumu: " + gonderimDurumu +
                                  "\nGönderim Cevabı Kodu: " + gonderimCevabiKodu +
                                  "\nGönderim Cevabı Detayı: " + gonderimCevabiDetayi +
                                  "\nYanıt Durumu: " + yanitDurumu +
                                  "\nYanıt Detayı: " + yanitDetayi +
                                  "\nUlaştı Mı?: " + ulastiMi +
                                  "\nYeniden Gönderilebilir Mi?: " + yenidenGonderilebilirMi +
                                  "\nBelgeNo (Yerel Belge No): " + belgeNo +
                                  "\nETTN(UUID): " + ettnDonen +
                                  "\nAlım Tarihi (eFinans'a Ulaşma Tarihi): " + alimTarihi +
                                  "\nOluşturulma Tarihi (imzalanıp Zarflanma tarihi): " + olusturulmaTarihi +
                                  "\nGönderim Tarihi: " + gonderimTarihi + //sistem gönderim tarihi
                                  "\nYanıt Tarihi: " + yanitTarihi +
                                  "\nyanitEttn: " + yanitEttn +      // İrsaliye için geçerlidir.
                                  "\nyanitVerilenBelgeEttn: " + yanitVerilenBelgeEttn   // İrsaliye için geçerlidir.
                                  };

                    System.IO.File.AppendAllLines(pathStr + "\\LogFile_" + dateStr + ".txt", hepsininAlayi);
                    tempFlag = flag;
                }

            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception'a düştü");
                Console.WriteLine(exp.Message);
                //++sayac;
                GidenBelgeDurumSorgulaExt(methods, belgeNoParam, vKN_TCKN);
            }
        }


        public static void GidenBelgeDurumSorgula(connectorService methods, string _belgeOid, string _vergiTcKimlikNo)
        {
            try
            {

                string durumAciklamaStr = "";
                string vergiTcKimlikNo = _vergiTcKimlikNo;
                string belgeOid = _belgeOid;  // "3sje027zxr100m";
                gidenBelgeDurum gidenBelDurum = methods.gidenBelgeDurumSorgula(vergiTcKimlikNo, belgeOid);
                string durumAciklama = gidenBelDurum.aciklama;
                string alimTarihi = gidenBelDurum.alimTarihi;
                string belgeNo = gidenBelDurum.belgeNo;
                int durumKodu = gidenBelDurum.durum;
                string ettn = gidenBelDurum.ettn;
                string gonderimCevabiDetayi = gidenBelDurum.gonderimCevabiDetayi;
                int gonderimCevabiKodu = gidenBelDurum.gonderimCevabiKodu;
                int gonderimDurumu = gidenBelDurum.gonderimDurumu;
                string gonderimTarihi = gidenBelDurum.gonderimTarihi;
                string olusturulmaTarihi = gidenBelDurum.olusturulmaTarihi;
                string yanitDetayi = gidenBelDurum.yanitDetayi;
                int yanitDurumu = gidenBelDurum.yanitDurumu;
                string yanitTarihi = gidenBelDurum.yanitTarihi;

                if (durumKodu == 1)
                {
                    Console.WriteLine("durumKodu == 1 kontrolü");
                    durumAciklamaStr = "Alındı Durumudur.\nDurum Kodu 2 veya 3 olana kadar beklenmelidir.\n";
                }
                if (durumKodu == 2)
                {
                    Console.WriteLine("durumKodu == 2 kontrolü");
                    durumAciklamaStr = "Fatura İşleme hatasıdır.\nHata nedenine göre düzeltip yeniden gönderiniz.\n";
                }
                if (durumKodu == 3)
                {
                    Console.WriteLine("durumKodu == 3 kontrolü");
                    durumAciklamaStr = "Fatura Başarıyla İşlenmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";

                    if (gonderimDurumu == -2)
                    {
                        Console.WriteLine("gonderimDurumu == -2 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi. İptal edildi, gönderilmeyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == -1)
                    {
                        Console.WriteLine("gonderimDurumu == -1 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderim kuyruğuna eklendi.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 0)
                    {
                        Console.WriteLine("gonderimDurumu == 0 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi, sistem gönderim işlemini yeniden deneyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 1)
                    {
                        Console.WriteLine("gonderimDurumu == 1 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 2)
                    {
                        Console.WriteLine("gonderimDurumu == 2 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 3)
                    {
                        Console.WriteLine("gonderimDurumu == 3 kontrolü");
                        if (gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura gönderiminde hata bulunmuştur. Hata mesajı aynı metodun diğer parametrelerinden görüntülenebilir. Hata kodlarının açıklamaları kılavuzdadır.";
                        }
                        if (gonderimCevabiKodu == 1200)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura GIB'le Alıcı arasındadır.";
                        }

                        if (gonderimCevabiKodu == 1210 || gonderimCevabiKodu == 1220)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura tekrar gönderilemez. Alıcı uyarılmalı ve sisteminin kontrol edilmesi gerektiği iletilmelidir. İşlem başarısızdır.";
                        }
                    }
                    if (gonderimDurumu == 4)
                    {
                        Console.WriteLine("gonderimDurumu == 4 kontrolü");
                        if (gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300)
                        {
                            Console.WriteLine("gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300 kontrolü");
                            durumAciklamaStr = "Fatura Alıcıya ulaşmıştır.";

                            if (yanitDurumu == -1)
                            {
                                Console.WriteLine("yanitDurumu == -1 kontrolü");
                                durumAciklamaStr = "Temel Faturadır. Karşıdan yanıt beklenmez.";
                            }
                            if (yanitDurumu == 0)
                            {
                                Console.WriteLine("yanitDurumu == 0 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Karşıdan yanıt beklenmektedir.";
                            }
                            if (yanitDurumu == 1)
                            {
                                Console.WriteLine("yanitDurumu == 1 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Red Uygulama Yanıtı Alınmıştır.";
                            }
                            if (yanitDurumu == 2)
                            {
                                Console.WriteLine("yanitDurumu == 2 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Kabul Uygulama Yanıtı Alınmıştır.";
                            }
                        }

                    }
                }

                Console.WriteLine("\nDurum Kodu Açıklama: " + durumAciklamaStr +
                                  "\nDurum Açıklama: " + durumAciklama +
                                  "\nDurum Kodu: " + durumKodu +
                                  "\nGönderim Durumu: " + gonderimDurumu +
                                  "\nGönderim Cevabı Detayı: " + gonderimCevabiDetayi +
                                  "\nGönderim Cevabı Kodu: " + gonderimCevabiKodu +
                                  "\nYanıt Detayı: " + yanitDetayi +
                                  "\nYanıt Durumu: " + yanitDurumu +
                                  "\nAlım Tarihi: " + alimTarihi +
                                  "\nBelgeNo (Yerel Belge No): " + belgeNo +
                                  "\nETTN(UUID): " + ettn +
                                  "\nOluşturulma Tarihi: " + olusturulmaTarihi +
                                  "\nGönderim Tarihi: " + gonderimTarihi +
                                  "\nYanıt Tarihi: " + yanitTarihi 
                                  //"\nyanitEttn: " + gidenBelDurum.yanitEttn +
                                  //"\nyanitVerilenBelgeEttn: " + gidenBelDurum.yanitVerilenBelgeEttn
                                  );
                Console.ReadLine();


            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception'a düştü.");
                Console.WriteLine(exp.Message);
                //++sayac;
                //GidenBelgeDurumSorgula(methods);
            }
        }

        public static void GidenBelgeDurumSorgulaEttn(connectorService methods, string _vergiTcKimlikNo)
        {
            try
            {

                string vergiTcKimlikNo = _vergiTcKimlikNo;
                string ettn = null;
                gidenBelgeDurum gidenBelgeDurumEttn = methods.gidenBelgeDurumSorgulaEttn(vergiTcKimlikNo, ettn);

                string durumAciklamaStr = "";
                string durumAciklama = gidenBelgeDurumEttn.aciklama;
                string alimTarihi = gidenBelgeDurumEttn.alimTarihi;
                string belgeNo = gidenBelgeDurumEttn.belgeNo;
                int durumKodu = gidenBelgeDurumEttn.durum;
                string ettnStr = gidenBelgeDurumEttn.ettn;
                string gonderimCevabiDetayi = gidenBelgeDurumEttn.gonderimCevabiDetayi;
                int gonderimCevabiKodu = gidenBelgeDurumEttn.gonderimCevabiKodu;
                int gonderimDurumu = gidenBelgeDurumEttn.gonderimDurumu;
                string gonderimTarihi = gidenBelgeDurumEttn.gonderimTarihi;
                string olusturulmaTarihi = gidenBelgeDurumEttn.olusturulmaTarihi;
                string yanitDetayi = gidenBelgeDurumEttn.yanitDetayi;
                int yanitDurumu = gidenBelgeDurumEttn.yanitDurumu;
                string yanitTarihi = gidenBelgeDurumEttn.yanitTarihi;

                if (durumKodu == 1)
                {
                    Console.WriteLine("durumKodu == 1 kontrolü");
                    durumAciklamaStr = "Alındı Durumudur.\nDurum Kodu 2 veya 3 olana kadar beklenmelidir.\n";
                }
                if (durumKodu == 2)
                {
                    Console.WriteLine("durumKodu == 2 kontrolü");
                    durumAciklamaStr = "Fatura İşleme hatasıdır.\nHata nedenine göre düzeltip yeniden gönderiniz.\n";
                }
                if (durumKodu == 3)
                {
                    Console.WriteLine("durumKodu == 3 kontrolü");
                    durumAciklamaStr = "Fatura Başarıyla İşlenmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";

                    if (gonderimDurumu == -2)
                    {
                        Console.WriteLine("gonderimDurumu == -2 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi. İptal edildi, gönderilmeyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == -1)
                    {
                        Console.WriteLine("gonderimDurumu == -1 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderim kuyruğuna eklendi.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 0)
                    {
                        Console.WriteLine("gonderimDurumu == 0 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi, sistem gönderim işlemini yeniden deneyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 1)
                    {
                        Console.WriteLine("gonderimDurumu == 1 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 2)
                    {
                        Console.WriteLine("gonderimDurumu == 2 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 3)
                    {
                        Console.WriteLine("gonderimDurumu == 3 kontrolü");
                        if (gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura gönderiminde hata bulunmuştur. Hata mesajı aynı metodun diğer parametrelerinden görüntülenebilir. Hata kodlarının açıklamaları kılavuzdadır.";
                        }
                        if (gonderimCevabiKodu == 1200)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura GIB'le Alıcı arasındadır.";
                        }

                        if (gonderimCevabiKodu == 1210 || gonderimCevabiKodu == 1220)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura tekrar gönderilemez. Alıcı uyarılmalı ve sisteminin kontrol edilmesi gerektiği iletilmelidir. İşlem başarısızdır.";
                        }
                    }
                    if (gonderimDurumu == 4)
                    {
                        Console.WriteLine("gonderimDurumu == 4 kontrolü");
                        if (gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300)
                        {
                            Console.WriteLine("gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300 kontrolü");
                            durumAciklamaStr = "Fatura Alıcıya ulaşmıştır.";

                            if (yanitDurumu == -1)
                            {
                                Console.WriteLine("yanitDurumu == -1 kontrolü");
                                durumAciklamaStr = "Temel Faturadır. Karşıdan yanıt beklenmez.";
                            }
                            if (yanitDurumu == 0)
                            {
                                Console.WriteLine("yanitDurumu == 0 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Karşıdan yanıt beklenmektedir.";
                            }
                            if (yanitDurumu == 1)
                            {
                                Console.WriteLine("yanitDurumu == 1 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Red Uygulama Yanıtı Alınmıştır.";
                            }
                            if (yanitDurumu == 2)
                            {
                                Console.WriteLine("yanitDurumu == 2 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Kabul Uygulama Yanıtı Alınmıştır.";
                            }
                        }

                    }
                }

                Console.WriteLine("\nDurum Kodu Açıklama: " + durumAciklamaStr +
                                  "\nDurum Açıklama: " + durumAciklama +
                                  "\nDurum Kodu: " + durumKodu +
                                  "\nGönderim Durumu: " + gonderimDurumu +
                                  "\nGönderim Cevabı Detayı: " + gonderimCevabiDetayi +
                                  "\nGönderim Cevabı Kodu: " + gonderimCevabiKodu +
                                  "\nYanıt Detayı: " + yanitDetayi +
                                  "\nYanıt Durumu: " + yanitDurumu +
                                  "\nAlım Tarihi: " + alimTarihi +
                                  "\nBelgeNo (Yerel Belge No): " + belgeNo +
                                  "\nETTN(UUID): " + ettnStr +
                                  "\nOluşturulma Tarihi: " + olusturulmaTarihi +
                                  "\nGönderim Tarihi: " + gonderimTarihi +
                                  "\nYanıt Tarihi: " + yanitTarihi 
                                  //"\nyanitEttn: " + gidenBelgeDurumEttn.yanitEttn +  //irsaliyeye özel
                                  //"\nyanitVerilenBelgeEttn: " + gidenBelgeDurumEttn.yanitVerilenBelgeEttn // irsaliyeye özel
                                  );
                Console.ReadLine();


            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception'a düştü.");
                Console.WriteLine(exp.Message);
                //++sayac;
                //GidenBelgeDurumSorgula(methods);
            }
        }


        public static void GidenBelgeDurumSorgulaYerelBelgeNo(connectorService methods, string _vergiTcKimlikNo)
        {
            try
            {

                string vergiTcKimlikNo = _vergiTcKimlikNo;
                string yerelBelgeNo = null;
                gidenBelgeDurum gidenBelgeDurumYerelBelgeNo = methods.gidenBelgeDurumSorgulaYerelBelgeNo(vergiTcKimlikNo, yerelBelgeNo);

                string durumAciklamaStr = "";
                string durumAciklama = gidenBelgeDurumYerelBelgeNo.aciklama;
                string alimTarihi = gidenBelgeDurumYerelBelgeNo.alimTarihi;
                string belgeNo = gidenBelgeDurumYerelBelgeNo.belgeNo;
                int durumKodu = gidenBelgeDurumYerelBelgeNo.durum;
                string ettnStr = gidenBelgeDurumYerelBelgeNo.ettn;
                string gonderimCevabiDetayi = gidenBelgeDurumYerelBelgeNo.gonderimCevabiDetayi;
                int gonderimCevabiKodu = gidenBelgeDurumYerelBelgeNo.gonderimCevabiKodu;
                int gonderimDurumu = gidenBelgeDurumYerelBelgeNo.gonderimDurumu;
                string gonderimTarihi = gidenBelgeDurumYerelBelgeNo.gonderimTarihi;
                string olusturulmaTarihi = gidenBelgeDurumYerelBelgeNo.olusturulmaTarihi;
                string yanitDetayi = gidenBelgeDurumYerelBelgeNo.yanitDetayi;
                int yanitDurumu = gidenBelgeDurumYerelBelgeNo.yanitDurumu;
                string yanitTarihi = gidenBelgeDurumYerelBelgeNo.yanitTarihi;

                if (durumKodu == 1)
                {
                    Console.WriteLine("durumKodu == 1 kontrolü");
                    durumAciklamaStr = "Alındı Durumudur.\nDurum Kodu 2 veya 3 olana kadar beklenmelidir.\n";
                }
                if (durumKodu == 2)
                {
                    Console.WriteLine("durumKodu == 2 kontrolü");
                    durumAciklamaStr = "Fatura İşleme hatasıdır.\nHata nedenine göre düzeltip yeniden gönderiniz.\n";
                }
                if (durumKodu == 3)
                {
                    Console.WriteLine("durumKodu == 3 kontrolü");
                    durumAciklamaStr = "Fatura Başarıyla İşlenmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";

                    if (gonderimDurumu == -2)
                    {
                        Console.WriteLine("gonderimDurumu == -2 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi. İptal edildi, gönderilmeyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == -1)
                    {
                        Console.WriteLine("gonderimDurumu == -1 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderim kuyruğuna eklendi.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 0)
                    {
                        Console.WriteLine("gonderimDurumu == 0 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi, sistem gönderim işlemini yeniden deneyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 1)
                    {
                        Console.WriteLine("gonderimDurumu == 1 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 2)
                    {
                        Console.WriteLine("gonderimDurumu == 2 kontrolü");
                        durumAciklamaStr = "Fatura GIB'e gönderilmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";
                    }
                    if (gonderimDurumu == 3)
                    {
                        Console.WriteLine("gonderimDurumu == 3 kontrolü");
                        if (gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura gönderiminde hata bulunmuştur. Hata mesajı aynı metodun diğer parametrelerinden görüntülenebilir. Hata kodlarının açıklamaları kılavuzdadır.";
                        }
                        if (gonderimCevabiKodu == 1200)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura GIB'le Alıcı arasındadır.";
                        }

                        if (gonderimCevabiKodu == 1210 || gonderimCevabiKodu == 1220)
                        {
                            Console.WriteLine("gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumAciklamaStr = "Fatura tekrar gönderilemez. Alıcı uyarılmalı ve sisteminin kontrol edilmesi gerektiği iletilmelidir. İşlem başarısızdır.";
                        }
                    }
                    if (gonderimDurumu == 4)
                    {
                        Console.WriteLine("gonderimDurumu == 4 kontrolü");
                        if (gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300)
                        {
                            Console.WriteLine("gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300 kontrolü");
                            durumAciklamaStr = "Fatura Alıcıya ulaşmıştır.";

                            if (yanitDurumu == -1)
                            {
                                Console.WriteLine("yanitDurumu == -1 kontrolü");
                                durumAciklamaStr = "Temel Faturadır. Karşıdan yanıt beklenmez.";
                            }
                            if (yanitDurumu == 0)
                            {
                                Console.WriteLine("yanitDurumu == 0 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Karşıdan yanıt beklenmektedir.";
                            }
                            if (yanitDurumu == 1)
                            {
                                Console.WriteLine("yanitDurumu == 1 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Red Uygulama Yanıtı Alınmıştır.";
                            }
                            if (yanitDurumu == 2)
                            {
                                Console.WriteLine("yanitDurumu == 2 kontrolü");
                                durumAciklamaStr = "Ticari Faturadır. Kabul Uygulama Yanıtı Alınmıştır.";
                            }
                        }

                    }
                }

                Console.WriteLine("\nDurum Kodu Açıklama: " + durumAciklamaStr +
                                  "\nDurum Açıklama: " + durumAciklama +
                                  "\nDurum Kodu: " + durumKodu +
                                  "\nGönderim Durumu: " + gonderimDurumu +
                                  "\nGönderim Cevabı Detayı: " + gonderimCevabiDetayi +
                                  "\nGönderim Cevabı Kodu: " + gonderimCevabiKodu +
                                  "\nYanıt Detayı: " + yanitDetayi +
                                  "\nYanıt Durumu: " + yanitDurumu +
                                  "\nAlım Tarihi: " + alimTarihi +
                                  "\nBelgeNo (Yerel Belge No): " + belgeNo +
                                  "\nETTN(UUID): " + ettnStr +
                                  "\nOluşturulma Tarihi: " + olusturulmaTarihi +
                                  "\nGönderim Tarihi: " + gonderimTarihi +
                                  "\nYanıt Tarihi: " + yanitTarihi 
                                  //"\nyanitEttn: " + gidenBelgeDurumYerelBelgeNo.yanitEttn +  //irsaliyeye özel
                                  //"\nyanitVerilenBelgeEttn: " + gidenBelgeDurumYerelBelgeNo.yanitVerilenBelgeEttn // irsaliyeye özel
                                  );
                Console.ReadLine();


            }
            catch (Exception exp)
            {
                Console.WriteLine("Exception'a düştü.");
                Console.WriteLine(exp.Message);
                //++sayac;
                //GidenBelgeDurumSorgula(methods);
            }
        }


        //Coklu olarak durum sorgulamak için kullanılmaktadır.
        public static void CokluGidenBelgeDurumSorgula(connectorService methods, string _vergiTcKimlikNo)
        {
            if (tempFlagBool != true)
            {
                Console.WriteLine("\n\nCokluGidenBelgeDurumSorgula\n**************************");
                tempFlagBool = true;
            }


            string pathStr = @"C:\TEMP";
            string durumKontrolu = "";

            string vergiTcKimlikNo = _vergiTcKimlikNo;
            gidenBelgeDurumParametreleri parametreler = new gidenBelgeDurumParametreleri();
            parametreler.belgeNoList = new string[] { };
            parametreler.belgeTuru = "FATURA_UBL";
            
            serviceReturnType[] cokluGidenBelgeDurum = methods.cokluGidenBelgeDurumSorgula(vergiTcKimlikNo, parametreler);

            foreach (gidenBelgeDurumv4 item in cokluGidenBelgeDurum)
            {
                string durumAciklamaStr = "";
                string durumAciklama = item.aciklama;  // işleme hatası alındığını gösteren durum = 2 'de açıklama geliyor.
                string alimTarihi = item.alimTarihi;
                string belgeNo = item.belgeNo;
                int durumKodu = item.durum;
                string ettnDonen = item.ettn;
                string gonderimCevabiDetayi = item.gonderimCevabiDetayi;
                int gonderimCevabiKodu = item.gonderimCevabiKodu;
                int gonderimDurumu = item.gonderimDurumu;
                string gonderimTarihi = item.gonderimTarihi;
                string olusturulmaTarihi = item.olusturulmaTarihi;
                string yanitDetayi = item.yanitDetayi;
                int yanitDurumu = item.yanitDurumu;
                string yanitTarihi = item.yanitTarihi;
                bool ulastiMi = item.ulastiMi;
                bool yenidenGonderilebilirMi = item.yenidenGonderilebilirMi;
                string gtbFiiliIhracatTarihi = item.gtbFiiliIhracatTarihi; //İhracat Faturalarına özeldir.
                string gtbGcbTescilNo = item.gtbGcbTescilNo;  //İhracat Faturalarına özeldir.
                string gtbRefNo = item.gtbRefNo;  //İhracat Faturalarına özeldir.
                //string yanitEttn = item.yanitEttn; //İrsaliye'ye özeldir.
                //string yanitVerilenBelgeEttn = item.yanitVerilenBelgeEttn; //İrsaliye'ye özeldir.
                string yerelBelgeOid = item.yerelBelgeOid;

                if (durumKodu == 1) // Fatura eFinans'a ulaşmıştır.
                {
                    //Console.WriteLine("\n*****durumKodu == 1 kontrolü");
                    durumKontrolu += "*****durumKodu == 1 kontrolü\n";
                    durumAciklamaStr = "Alındı Durumudur.\nDurum Kodu 2 veya 3 olana kadar beklenmelidir.\n";
                    //flag = 1;
                }
                if (durumKodu == 2)
                {
                    //Console.WriteLine("\n*****durumKodu == 2 kontrolü");
                    durumKontrolu += "*****durumKodu == 2 kontrolü\n";
                    durumAciklamaStr = "Fatura İşleme hatasıdır.\nHata nedenine göre düzeltip yeniden gönderiniz.\n";
                    //flag = 2;
                }
                if (durumKodu == 3)
                {
                    //Console.WriteLine("\n*****durumKodu == 3 kontrolü");
                    durumKontrolu += "*****durumKodu == 3 kontrolü\n";
                    durumAciklamaStr = "Fatura Başarıyla İşlenmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";
                    //flag = 3;
                    if (gonderimDurumu == -2)
                    {
                        //Console.WriteLine("*****gonderimDurumu == -2 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == -2 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi. İptal edildi, gönderilmeyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 4;
                    }
                    if (gonderimDurumu == -1)
                    {
                        //Console.WriteLine("*****gonderimDurumu == -1 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == -1 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderim kuyruğuna eklendi.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 5;
                    }
                    if (gonderimDurumu == 0)
                    {
                        //Console.WriteLine("*****gonderimDurumu == 0 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 0 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderilemedi, sistem gönderim işlemini yeniden deneyecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 6;
                    }
                    if (gonderimDurumu == 1)
                    {
                        //Console.WriteLine("*****gonderimDurumu == 1 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 1 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderilecek.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 7;
                    }
                    if (gonderimDurumu == 2)  //Fatura GIB'tedir.
                    {
                        //Console.WriteLine("*****gonderimDurumu == 2 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 2 kontrolü\n";
                        durumAciklamaStr = "Fatura GIB'e gönderilmiştir.\ngonderimDurum Kodlarını takip ediniz..\n";
                        //flag = 8;
                    }
                    if (gonderimDurumu == 3)
                    {
                        //Console.WriteLine("*****gonderimDurumu == 3 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 3 kontrolü\n";
                        //flag = 9;
                        if (gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu > 1100 && gonderimCevabiKodu < 1200 kontrolü\n";
                            durumAciklamaStr = "Fatura gönderiminde hata bulunmuştur. Hata mesajı aynı metodun gonderimCevabiDetayi parametresinde görüntülenebilir. Hata kodlarının açıklamaları kılavuzdadır.";
                            //flag = 10;
                        }
                        if (gonderimCevabiKodu == 1200)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1200 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1200 kontrolü\n";
                            durumAciklamaStr = "Fatura GIB'le Alıcı arasındadır.";
                            //flag = 11;
                        }

                        if (gonderimCevabiKodu == 1210)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1210 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1210 kontrolü\n";
                            durumAciklamaStr = "GİB, alıcıya zarfı iletmeye çalışmış ancak iletememiştir. Durumun alıcıya iletilmesi faydalı olacaktır. Ancak bu durum GİB ile alıcı firmanın sistemleri arasındaki bağlantının geçici olarak kopmasından kaynaklanıyor olabilir. GİB zarfı toplamda 4 defa daha belirli aralıklarla göndermeyi deneyecektir. Bu durumda fatura yeniden gönderilmez, durumun değişmesi beklenir. Eğer zarf alıcıya başarıyla iletilirse zarfın durumu 1220, tüm denemeler sonrasında iletilemezse 1215 olur.";
                            durumAciklamaStr += "\n1220 durumunda alıcıdan yeni bir sistem yanıtının gelmesi beklenir. ";
                            //flag = 12;
                        }

                        if (gonderimCevabiKodu == 1215)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1215 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1215 kontrolü\n";
                            durumAciklamaStr = "GİB, alıcıya zarfı ilk gönderim dahil 5 defa göndermeye çalışmış ancak hiçbiri başarılı olmamıştır. Alıcıya bilgi verilmelidir. Bu durumdaki fatura aynı fatura numarasıyla farklı bir zarfla yeniden gönderilebilir.";
                            durumAciklamaStr += "\nbelgeTekrarGonder\nbelgeTekrarGonderBelgeOid\nbelgeTekrarGonderYerelBelgeNo\n metotlarından biri kullanılabilir.";
                            //flag = 13;
                        }

                        if (gonderimCevabiKodu == 1220)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1220 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1220 kontrolü\n";
                            durumAciklamaStr = "GİB, alıcıya zarfı başarıyla iletmiş ancak alıcıdan henüz sistem yanıtı gelmemiştir. Alıcıdan başarısız sistem yanıtı gelene kadar fatura alıcıya iletilmiş sayılmaktadır.  Bu durumda fatura yeniden gönderilmez, alıcıdan sistem yanıtının gelmesi beklenir.";
                            //flag = 14;
                        }

                        if (gonderimCevabiKodu == 1230)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1230 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1230 kontrolü\n";
                            durumAciklamaStr = "Alıcıdan GİB'e, zarfın sistem yanıtı başarısız olarak gelmiştir. Bu durumda fatura iletilmiş sayılmamaktadır. Bu durumdaki fatura aynı fatura numarasıyla farklı bir zarfla yeniden gönderilebilir.";
                            durumAciklamaStr += "\nbelgeTekrarGonder\nbelgeTekrarGonderBelgeOid\nbelgeTekrarGonderYerelBelgeNo\n metotlarından biri kullanılabilir.";
                            //flag = 15;
                        }
                    }
                    if (gonderimDurumu == 4) //Fatura alıcıdadır.
                    {
                        //Console.WriteLine("*****gonderimDurumu == 4 kontrolü");
                        durumKontrolu += "*****gonderimDurumu == 4 kontrolü\n";
                        //flag = 16;
                        if (gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300)
                        {
                            //Console.WriteLine("*****gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300 kontrolü");
                            durumKontrolu += "*****gonderimCevabiKodu == 1200 || gonderimCevabiKodu == 1300 kontrolü\n";
                            durumAciklamaStr = "Fatura Alıcıya ulaşmıştır.";
                            //flag = 17;

                            if (yanitDurumu == -1)
                            {
                                //Console.WriteLine("*****yanitDurumu == -1 kontrolü");
                                durumKontrolu += "*****yanitDurumu == -1 kontrolü\n";
                                durumAciklamaStr = "Temel Faturadır. Karşıdan yanıt beklenmez.";
                                //flag = 18;
                            }
                            if (yanitDurumu == 0)
                            {
                                //Console.WriteLine("*****yanitDurumu == 0 kontrolü");
                                durumKontrolu += "*****yanitDurumu == 0 kontrolü\n";
                                durumAciklamaStr = "Ticari Faturadır. Karşıdan yanıt beklenmektedir.";
                                //flag = 19;
                            }
                            if (yanitDurumu == 1)
                            {
                                //Console.WriteLine("*****yanitDurumu == 1 kontrolü");
                                durumKontrolu += "*****yanitDurumu == -1 kontrolü\n";
                                durumAciklamaStr = "Ticari Faturadır. Red Uygulama Yanıtı Alınmıştır.";
                                //flag = 20;
                            }
                            if (yanitDurumu == 2)
                            {
                                //Console.WriteLine("yanitDurumu == 2 kontrolü");
                                durumKontrolu += "*****yanitDurumu == 2 kontrolü\n";
                                durumAciklamaStr = "Ticari Faturadır. Kabul Uygulama Yanıtı Alınmıştır.";
                                //flag = 21;
                            }
                        }

                    }
                }

                if (tempFlagBool == false)  // Giriş Parametrelerini bir kez görüntülemek için bu kontrol eklenmiştir.
                {
                    Console.WriteLine("\nGiriş Parametreleri: \n*********************" +
                                      "\nBelgeNo: " + parametreler.belgeNo +
                                      "\nBelgeNo Tipi: " + parametreler.belgeNoTipi +
                                      "\nBelge Türü: " + parametreler.belgeTuru +
                                      "\nDönüş Tipi Versiyon: " + parametreler.donusTipiVersiyon);
                    tempFlagBool = true;
                    Process.Start(pathStr);
                }


                flag = durumKodu + gonderimDurumu + gonderimCevabiKodu + yanitDurumu;
                if (flag != tempFlag)
                {
                    Console.WriteLine("\nDurum Kodu Açıklama: \n" + durumKontrolu + "\n" + durumAciklamaStr +
                                      "\nDurum Açıklama: " + durumAciklama +
                                      "\nDurum Kodu: " + durumKodu +
                                      "\nGönderim Durumu: " + gonderimDurumu +
                                      "\nGönderim Cevabı Kodu: " + gonderimCevabiKodu +
                                      "\nGönderim Cevabı Detayı: " + gonderimCevabiDetayi +
                                      "\nYanıt Durumu: " + yanitDurumu +
                                      "\nYanıt Detayı: " + yanitDetayi +
                                      "\nUlaştı Mı?: " + ulastiMi +
                                      "\nYeniden Gönderilebilir Mi?: " + yenidenGonderilebilirMi +
                                      "\nBelgeNo (Yerel Belge No): " + belgeNo +
                                      "\nETTN(UUID): " + ettnDonen +
                                      "\nAlım Tarihi (eFinans'a Ulaşma Tarihi): " + alimTarihi +
                                      "\nOluşturulma Tarihi: " + olusturulmaTarihi +
                                      "\nGönderim Tarihi: " + gonderimTarihi +
                                      "\nYanıt Tarihi: " + yanitTarihi 
                                      //"\nyanitEttn: " + yanitEttn +      // İrsaliye için geçerlidir.
                                      //"\nyanitVerilenBelgeEttn: " + yanitVerilenBelgeEttn// İrsaliye için geçerlidir.
                                      );  


                    string[] hepsininAlayi = {"\n\n---------------------------------\nGidenBelgeDurumSorgulaExt\n***************************"+
                                  "\nDurum Kodu Açıklama: \n" + durumKontrolu + durumAciklamaStr +
                                  "\nDurum Açıklama: " + durumAciklama +
                                  "\nDurum Kodu: " + durumKodu +
                                  "\nGönderim Durumu: " + gonderimDurumu +
                                  "\nGönderim Cevabı Kodu: " + gonderimCevabiKodu +
                                  "\nGönderim Cevabı Detayı: " + gonderimCevabiDetayi +
                                  "\nYanıt Durumu: " + yanitDurumu +
                                  "\nYanıt Detayı: " + yanitDetayi +
                                  "\nUlaştı Mı?: " + ulastiMi +
                                  "\nYeniden Gönderilebilir Mi?: " + yenidenGonderilebilirMi +
                                  "\nBelgeNo (Yerel Belge No): " + belgeNo +
                                  "\nETTN(UUID): " + ettnDonen +
                                  "\nAlım Tarihi (eFinans'a Ulaşma Tarihi): " + alimTarihi +
                                  "\nOluşturulma Tarihi (imzalanıp Zarflanma tarihi): " + olusturulmaTarihi +
                                  "\nGönderim Tarihi: " + gonderimTarihi + //sistem gönderim tarihi
                                  "\nYanıt Tarihi: " + yanitTarihi 
                                  //"\nyanitEttn: " + yanitEttn +      // İrsaliye için geçerlidir.
                                  //"\nyanitVerilenBelgeEttn: " + yanitVerilenBelgeEttn // İrsaliye için geçerlidir.
                                  };  

                    System.IO.File.AppendAllLines(pathStr + "\\LogFile_" + dateStr + ".txt", hepsininAlayi);
                    tempFlag = flag;
                }
            }
        }
    }

}

