﻿using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eFinansPortalTestEFaturaConsoleWS
{
    public static class GelenBelgeleriListelemeClass
    {
        private static string pathStr = @"C:\TEMP";

        //dateStr değişkeni, Log Dosyası isimlendirmesi için kullanılmaktadır.
        private static string dateStr = DateTime.Now.ToString("yyyyMMddHHmmss");

       private static void pathOlustur(string pathStr)
        {
            if (!System.IO.Directory.Exists(pathStr))
            {
                System.IO.Directory.CreateDirectory(pathStr);
                
            }
        }

        //Bir defa da en fazla 100 fatura listelenmektedir.
        //Tarih kriterlerine göre listeleme metotu kullanıldığında,
        //belgelerAlindi metotu ile statüsü yerele aktarıldı olarak işaretlenen faturalar listelenmeyecektir.
        //diğer kriterlerin hepsinde bu metot kullanılmış olsa da bütün faturalar sırasıyla listelenecektir.
        public static string[] GelenBelgeleriListeleExt(connectorService methods, string vergiTcKimlikNoParam)
        {
            pathOlustur(pathStr);
            string[] ettnler = new string[100]; // bir defada 100 belge listelenmektedir.

            gelenBelgeParametreleri parametreler = new gelenBelgeParametreleri();
            parametreler.vergiTcKimlikNo = vergiTcKimlikNoParam;
            parametreler.belgeTuru = "FATURA";       // "FATURA" veya "UYGULAMA_YANITI" değerleri alabilir. 
            //parametreler.belgeFormati = "UBL";     // "UBL", "HTML", "PDF" değerlerini alabilir. gelenBelgeleriAlExt, gelenBelgeleriIndir gibi indirme metotlarında kullanılır. listelemede kullanılamaz.
            parametreler.donusTipiVersiyon = "5.0";  // "1.0" ise belge; "2.0" ise belgev2 değeri alır.
            //parametreler.belgeVersiyon = "3.0";    // "1.0", "2.0", "3.0" değerlerini alabilir. gelenBelgeleriAlExt metotunda aktif olarak kullanılmaktadır.
            parametreler.erpKodu = "ERP1";       // eFinans tarafından ERP bazlı oluşturulan statik bir değerdir. 

            /* “sonAlinanBelgeSiraNumarasi” parametresi ile birlikte 
            “gelisTarihiBaslangic“, “gelisTarihiBitis “, “onayDurum “,  “subeKodu“ ve “alanEtiket“ parametrelerinden 
            bir ya da birkaçı girildiği taktirde sistem parametreleri hatalı kabul edecek 
            ve işlemi gerçekleştirmeyecektir. */

            //parametreler.sonAlinanBelgeSiraNumarasi = "0";  // Belgeleri sırasıyla çekmeyi sağlar.

            /* parametreler.alanEtiket parametresi: Firmanın birden fazla etiketinin mevcut olduğu durumlarda 
            sadece belirli etiketlerine gelen faturaları listelemek için bu alan doldurulabilir.
            Bu alan hiç kullanılmadığında bütün etiketlere gelen faturalar listelenmektedir. */

            //parametreler.alanEtiket = defaultpk;

            /*Belirli bir onay durumunda olan faturaların listelenmesi için kullanılır. 
             “ONAYBEKLEYEN”, “ONAYLANAN”, “HEPSI” değerlerinden birini alabilir. 
             Boş bırakılması durumunda sadece “ONAYLANAN” faturalar listelenecektir. */

            //parametreler.onayDurum = "HEPSI"; 

            parametreler.ettn = new string[] { "e6148d53-4aa6-45ce-9fef-acb3287b342a" }; //Yalnızca belirtilen ettn'li faturaları listeler.

            //parametreler.gelisTarihiBaslangic = "20131220000000000";      // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.gelisTarihiBitis = "20140923000000000";          // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.faturaTarihiBaslangic = "20131220000000000";     // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 
            //parametreler.faturaTarihiBitis = "20140923000000000";         // YYYYAAGGSSDDssMMM (YılAyGünSaatDakikaSaniyeSalise) 

            //parametreler.gonderenEtiket;      // pasiftir. Kullanılmasına gerek bulunmamaktadır.
            //parametreler.subeKodu;            // pasiftir. Kullanılmasına gerek bulunmamaktadır.
            //parametreler.entegrasyonHedefi;   // pasiftir. Kullanılmasına gerek bulunmamaktadır.

            serviceReturnType[] gelenBelgeleriListeleExtObj = methods.gelenBelgeleriListeleExt(parametreler);

            /*
            foreach (belge gelenBelgeleriAlValue in gelenBelgeleriListeleExtObj)
            {
                
                string belgeNo = gelenBelgeleriAlValue.belgeNo;
                string belgeSiraNo = gelenBelgeleriAlValue.belgeSiraNo;
                string belgeTarihi = gelenBelgeleriAlValue.belgeTarihi;
                string belgeTuruRes = gelenBelgeleriAlValue.belgeTuru;
                //string belgeVerisi = gelenBelgeleriAlValue.belgeVerisi;  // listeleme methodlarında boş gelmektedir.
                string ETTN = gelenBelgeleriAlValue.ettn;
                string gonderenEtiket = gelenBelgeleriAlValue.gonderenEtiket;
                string gonderenVknTckn = gelenBelgeleriAlValue.gonderenVknTckn;

                Console.WriteLine("\nBelgeNo: " + belgeNo +
                                  "\nBelgeSıraNo: " + belgeSiraNo +
                                  "\nBelge Tarihi: " + belgeTarihi +
                                  "\nBelge Türü: " + belgeTuruRes +
                                  //"\nBelge Verisi: " + belgeVerisi+
                                  "\nETTN: " + ETTN +
                                  "\nGönderen Etiket: " + gonderenEtiket +
                                  "\nGönderen VKN_TCKN: " + gonderenVknTckn);
            }
            */

            /*
            for (int i = 0; i < gelenBelgeleriListeleExtObj.Length; i++) //gelenBelgeleriListeleExtObj.Length = 100 olarak da kabul edebilirsiniz.
            {
                belgev2 item = (belgev2)gelenBelgeleriListeleExtObj[i];  //casting

                string alanEtiketi = item.alanEtiket;
                string aliciUnvan = item.aliciUnvan;
                string belgeNo = item.belgeNo;
                string belgeSiraNo = item.belgeSiraNo;
                string belgeTarihi = item.belgeTarihi;
                string belgeTuru = item.belgeTuru;
                string ETTN = item.ettn;
                string gonderenEtiket = item.gonderenEtiket;
                string gonderenVknTckn = item.gonderenVknTckn;
                string saticiUnvan = item.saticiUnvan;
                string zarfId = item.zarfId;

                Console.WriteLine("\nAlıcı Ünvan: " + aliciUnvan +
                  "\nSatıcı Ünvan: " + saticiUnvan +
                  //"\nBelge Versiyon: " + belgeVersiyon +
                  "\nAlan Etiket: " + alanEtiketi +
                  "\nGönderen Etiket: " + gonderenEtiket +
                  "\nGönderen VKN_TCKN: " + gonderenVknTckn +
                  "\nBelge Türü: " + belgeTuru +
                  //"\nŞube Kodu: " + subeKodu + // pasiftir.
                  "\nZarfID: " + zarfId +
                  //"\nZarfXML: " + zarfXml + // Listeleme metotunda aktif değildir.
                  "\nETTN: " + ETTN +
                  "\nBelge No: " + belgeNo +
                  "\nBelge Sıra No: " + belgeSiraNo +
                  "\nBelge Tarihi: " + belgeTarihi
                  //"\nBelge Verisi: " + belgeVerisi
                  );
            }
            */

            int sayac = 0;
            foreach (belgev5 item in gelenBelgeleriListeleExtObj)
            {
                
                string alanEtiketi = item.alanEtiket;
                string aliciUnvan = item.aliciUnvan;
                string belgeNo = item.belgeNo;
                string belgeSiraNo = item.belgeSiraNo;
                string belgeTarihi = item.belgeTarihi;
                string belgeTuru = item.belgeTuru;
                string ETTN = item.ettn;
                string gonderenEtiket = item.gonderenEtiket;
                string gonderenVknTckn = item.gonderenVknTckn;
                string saticiUnvan = item.saticiUnvan;
                string zarfId = item.zarfId;
                string _faturaGelisTarihi = item.faturaGelisTarihi;
                string _belgeHash = item.belgeHash;

                //string subeKodu = item.subeKodu;         // Şimdilik pasiftir
                //string belgeVerisi = item.belgeVerisi;        // Listeleme metotunda boş gelecektir.
                //string belgeVersiyon = item.belgeVersiyon;    // Listeleme metotunda dikkate alınmasına gerek bulunmamaktadır.
                //byte[] belgeXmlZipped = item.belgeXmlZipped;  // Listeleme metotunda boş gelecektir.
                //belgev2Entry[] ekBilgiler = item.ekBilgiler;  // Listeleme metotunda boş gelecektir.
                //byte[] zarfVerisi = item.zarfVerisi;      //  Listeleme metotunda boş gelecektir.
                //string zarfXml = item.zarfXml;            //  Listeleme metotunda boş gelecektir.


                Console.WriteLine("\nAlıcı Ünvan: " + aliciUnvan +
                                  "\nSatıcı Ünvan: " + saticiUnvan +
                                  //"\nBelge Versiyon: " + belgeVersiyon +
                                  "\nAlan Etiket: " + alanEtiketi +
                                  "\nGönderen Etiket: " + gonderenEtiket +
                                  "\nGönderen VKN_TCKN: " + gonderenVknTckn +
                                  "\nBelge Türü: " + belgeTuru +
                                  //"\nŞube Kodu: " + subeKodu + // pasiftir.
                                  "\nZarfID: " + zarfId +
                                  //"\nZarfXML: " + zarfXml + // Listeleme metotunda aktif değildir.
                                  "\nETTN: " + ETTN +
                                  "\nBelge No: " + belgeNo +
                                  "\nBelge Sıra No: " + belgeSiraNo +
                                  "\nBelge Tarihi: " + belgeTarihi +
                                  "\nFatura Geliş Tarihi: " + _faturaGelisTarihi +
                                  "\nBelge Hash: " + _belgeHash
                                  //"\nBelge Verisi: " + belgeVerisi
                                  );

                ++sayac;

                ettnler[sayac - 1] = ETTN;
                string[] hepsininAlayi = {"\nAlıcı Ünvan: " + aliciUnvan +
                                  "\nSatıcı Ünvan: " + saticiUnvan +
                                  "\nAlan Etiket: " + alanEtiketi +
                                  "\nGönderen Etiket: " + gonderenEtiket +
                                  "\nGönderen VKN_TCKN: " + gonderenVknTckn +
                                  "\nBelge Türü: " + belgeTuru +
                                  "\nZarfID: " + zarfId +
                                  "\nETTN: " + ETTN +
                                  "\nBelge No: " + belgeNo +
                                  "\nBelge Sıra No: " + belgeSiraNo +
                                  "\nBelge Tarihi: " + belgeTarihi
                                  //"\nFatura Geliş Tarihi: " + _faturaGelisTarihi +
                                  //"\nBelge Hash: " + _belgeHash
                                };
                System.IO.File.AppendAllLines(pathStr + "\\LogFile_" + dateStr + ".txt", hepsininAlayi);
            }
            
            //Console.WriteLine("\nToplam: " + sayac + " EFatura");

            return ettnler;
        }


        public static void GelenBelgeleriListele(connectorService methods, string vergiTcKimlikNoParam)
        {
            string vergiTcKimlikNo = vergiTcKimlikNoParam;
            string sonAlinanBelgeSiraNumarasi = "0";
            string belgeTuru = "FATURA";   // "FATURA" veya "UYGULAMA_YANITI" değerleri alabilir. 

            serviceReturnType[] gelenBelgeleriListeleValue = methods.gelenBelgeleriListele(vergiTcKimlikNo, sonAlinanBelgeSiraNumarasi, belgeTuru);

           
            int sayac = 0;
            foreach (belge gelenBelgeler in gelenBelgeleriListeleValue) 
            {
                

                string gonderenEtiket = gelenBelgeler.gonderenEtiket;
                string gonderenVknTckn = gelenBelgeler.gonderenVknTckn;
                string ETTN = gelenBelgeler.ettn;
                string belgeNo = gelenBelgeler.belgeNo;
                string belgeSiraNo = gelenBelgeler.belgeSiraNo;
                string belgeTarihi = gelenBelgeler.belgeTarihi;
                string belgeTuruRes = gelenBelgeler.belgeTuru;
                //string belgeVerisi = gelenBelgeler.belgeVerisi;  // listeleme metotunda pasiftir.

                Console.WriteLine("\nGönderen Etiket: " + gonderenEtiket +
                                  "\nGönderen VKN_TCKN: " + gonderenVknTckn +
                                  "\nETTN: " + ETTN +
                                  "\nBelge No: " + belgeNo +
                                  "\nBelge Sıra No: " + belgeSiraNo +
                                  "\nBelge Tarihi: " + belgeTarihi +
                                  "\nBelge Türü: " + belgeTuruRes 
                                  //"\nBelge Verisi: " + belgeVerisi  // listeleme metotunda pasiftir.
                                  );
                ++sayac;
            }

            Console.WriteLine("\nToplam: " + sayac + " EFatura");

        }
    }
}
