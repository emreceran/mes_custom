﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eFinansPortalTestEFaturaConsoleWS.PortalTestEFatura;
using System.Security.Cryptography;
using eFinansPortalTestEFaturaConsoleWS.Login;
using System.Net;

namespace eFinansPortalTestEFaturaConsoleWS
{
    class Program
    {
        
      

        static void Main(string[] args)
        {
            Login.userService login = new Login.userService();
            PortalTestEFatura.connectorService methods = new PortalTestEFatura.connectorService();
            try
            {
                
                

                login.CookieContainer = new System.Net.CookieContainer();
                methods.CookieContainer = login.CookieContainer;
                
                string VKN_TCKN = "VKN_TCKN";

                string userId = "UserID";
                string password = "Password";
                

       

                login.wsLogin(userId, password, "tr");


                Console.WriteLine("###################");

				//Methodlar çağrılır.
                BelgeGonderExt(methods, VKN_TCKN)
                
            }
            catch (Exception exp)
            {
                Console.WriteLine(exp.Message);
            }
            finally
            {
                login.logout();
            }

       
            Console.WriteLine("Bitti...");
            Console.ReadLine();

        }
        public static string BelgeGonderExt(connectorService methods, string _vergiTcKimlikNoParam)
        {
            string belgeGonderMsgOid = "";

            try
            {
                
                Console.WriteLine("\n\nBelgeGonderExt");
                gidenBelgeParametreleri parametreler = new gidenBelgeParametreleri();

                parametreler.vergiTcKimlikNo = _vergiTcKimlikNoParam;  //Zorunludur. Gönderici VKN_TCKN
                parametreler.belgeTuru = "IRSALIYE_UBL";         // Zorunludur. FATURA (CSXML içindir),  FATURA_UBL, UYGULAMA_YANITI (CSXML içindir), UYGULAMA_YANITI_UBL, IRSALIYE_UBL, IRSALIYE (CSXML içindir), IRSALIYE_YANITI_UBL, IRSALIYE_YANITI (CSXML içindir) değerlerini alabilir.
                parametreler.belgeNo = Guid.NewGuid().ToString(); // Zorunludur. yerelBelgeNo'dur. Gönderilen belgenin gönderici tarafındaki tekil anahtarıdır. 
                parametreler.veri = System.IO.File.ReadAllBytes(@"C:\Irsaliye.xml"); // Zorunludur. belgeTuru parametresinde belirtilen değere göre fatura veya irsaliye xml'idir.
                parametreler.belgeHash = GetMD5Hash(parametreler.veri); // Zorunludur. irsaiye veya fatura xml'inin MD5 ile hash'lenmesidir.
                parametreler.mimeType = "application/xml";  // Zorunludur. xml için sadece bu değeri alabilir. sabittir. statiktir.
                parametreler.belgeVersiyon = "1.0";  //CSXML kullanılıyorsa Zorunludur. CSXML için 1.0, 2.0, 3.0 değerlerini alabilir. UBL için 1.2 kullanılabilir ya da hiç kullanılmayabilir. Irsaliye için 1.0 'dır.
                parametreler.erpKodu = "ERP1"; //  Zorunludur. Her ERP için eFinans tarafından tanımlanan koddur. ilgili ERP'yi kullanan firmaların önceden eFinans'ta tanımı yapılmalıdır. ERP kurulmadan destek@efinans.com.tr'ye mail atılmalıdır.
                //parametreler.alanEtiket = "defaultpk";    //mükellef listeleme metodundan elde edilen pk'lar buradan parametre olarak verilebilir. Eğer verilmezse ilk pk'larına gidecektir.
                //parametreler.gonderenEtiket = "defaultgb"
                //parametreler.xsltAdi = "Ornek.xslt";
                //parametreler.xsltVeri = System.IO.File.ReadAllBytes(@"C:\GENEL.xslt");
                

                belgeGonderMsgOid = methods.belgeGonderExt(parametreler);

                Console.WriteLine("VergiTC Kimlik No: " + parametreler.vergiTcKimlikNo +
                                  "\nBelge Türü: " + parametreler.belgeTuru +
                                  "\nBelge No(Yerel Belge No): " + parametreler.belgeNo);

                Console.WriteLine("Belge MesajOid: " + belgeGonderMsgOid);

                Console.WriteLine();
                return belgeGonderMsgOid;

            }
            catch (Exception exp)
            {

                Console.WriteLine(exp.Message);
                return belgeGonderMsgOid;
            }

        }


        public static string GetMD5Hash(byte[] gelen)
        {
            //Fatura dosyalarının hash'lerini almak için kullanılan fonksiyondur.
            MD5 md5Hash = new MD5CryptoServiceProvider();
            byte[] data = md5Hash.ComputeHash(gelen);
            StringBuilder sBuilder = new StringBuilder();
            
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            return sBuilder.ToString();
        }
    }
}
