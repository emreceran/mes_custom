<?php
ini_set('display_errors',0);


function soapClientWSSecurityHeader($user, $password)
   {
      // Sistem saatini tutuyoruz yyyy-mm-ddThh:mm:ssZ format bu.
      $tm_created = gmdate('Y-m-d\TH:i:s\Z');
      $tm_expires = gmdate('Y-m-d\TH:i:s\Z', gmdate('U') + 180); //only necessary if using the timestamp element

      // Rastgele bir sayı üretmek için lazım olursa kullanılacak. İşlemlerde kullanılabilir kalsın
     // $simple_nonce = mt_rand();
     //$encoded_nonce = base64_encode($simple_nonce);

      // Belki Şifre sha ile şifrelenir diye yazdım ama gerekmiyormuş.
      //$passdigest = base64_encode(sha1($simple_nonce . $tm_created . $password, true));

      // Header da bulunan namespace adreslerini çekiyoruz.
      $ns_wsse = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd';
      $ns_wsu = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd';
      $password_type = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest';
      $encoding_type = 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary';

      // // SimpleXML kullanarak WSS kimlik başlığını oluşturma
      $root = new SimpleXMLElement('<root/>');

      $security = $root->addChild('wsse:Security', null, $ns_wsse);

      //zaman damgası elemanı tüm sunucular tarafından gerekli değildir.
      $timestamp = $security->addChild('wsu:Timestamp', null, $ns_wsu);
      $timestamp->addAttribute('wsu:Id', 'Timestamp-28');
      $timestamp->addChild('wsu:Created', $tm_created, $ns_wsu);
      $timestamp->addChild('wsu:Expires', $tm_expires, $ns_wsu);
	  
	  
      // asıl iş burda header başlıklarını oluşturuyoruz Soap header
      $usernameToken = $security->addChild('wsse:UsernameToken', null, $ns_wsse);
      $usernameToken->addChild('wsse:Username', $user, $ns_wsse);
      $usernameToken->addChild('wsse:Password', $password, $ns_wsse)->addAttribute('Type', $password_type);
      $usernameToken->addChild('wsse:Nonce', $encoded_nonce, $ns_wsse)->addAttribute('EncodingType', $encoding_type);
      $usernameToken->addChild('wsu:Created', $tm_created, $ns_wsu);

      // Oluşan nesnenin XML ini kurtar, bağlantıya ver
      $root->registerXPathNamespace('wsse', $ns_wsse);
      $full = $root->xpath('/root/wsse:Security');
      $auth = $full[0]->asXML();
	  
	  //Efinans üzerine gönderiklen cookie bilgilerini teyid etmek için yazdım. Kullanıcı adı şifreyi ekrana basıyor.
	 // echo"<pre>";
	 // print_r($auth);
	  //echo"</pre>";
	  	  

      return new SoapHeader($ns_wsse, 'Security', new SoapVar($auth, XSD_ANYXML), true);
  
  
  
   }
   
   
   
$client = new SoapClient('https://connectortest.efinans.com.tr/connector/ws/connectorService?wsdl');
$client->__setSoapHeaders(soapClientWSSecurityHeader('kullanıcı adı','Şifre'));
 
///SOAP BAĞLANTI BURAYA KADAR

// BUNDAN SONRA GELEN VERİLERİ BASIYORUZ


try {


$soapResult = $client->__soapCall(kayitliKullaniciListeleExtended, array(array(urun=>'EFATURA',gecmisEklensin=>'1'))) ;


foreach($soapResult as $sonuc)
{
     
$encode = base64_encode($sonuc);

$decoded  = base64_decode($encode);

$file = 'invoice.zip';
file_put_contents($file, $decoded);



if (file_exists($file)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="'.basename($file).'"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    readfile($file);
    echo'Liste başarıyla indirildi';
}
 
}


}   catch (SoapFault $e) {
    exit($e->getMessage());
}



   ?>

</body>
</html>