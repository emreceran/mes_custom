/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package efinansefaturawsconsole;

/**
 *
 * @author osman.cuhadar
 */
public class EFinansEFaturaWSConsole {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        String username = null;
        String password = null;
        
        Login8043 login8043 = new Login8043(username,password);
        Login8443 login8443 = new Login8443(username,password);
        
        byte[] veri = null;        
        login8043.port.belgeGonder(username, password, username, veri, username, username, username);
    }
    
}
