/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package efinansefaturawsconsole;

import java.util.Collections;
import java.util.Set;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

/**
 *
 * @author osman.cuhadar
 */
public class WebServiceSecurityHeaderHandler implements SOAPHandler<SOAPMessageContext> {
    public static final String REVISION_ID = "$Id: WebServiceSecurityHeaderHandler.java,v 1.1.2.2 2014/07/04 06:48:48 muhammedn Exp $";
    private static final String AUTH_NS = "http://schemas.xmlsoap.org/ws/2002/12/secext";
    private static final String AUTH_PREFIX = "wsse";
    private String userName = null;
    private String password = null;
    
    public WebServiceSecurityHeaderHandler() {
    }
    
    public WebServiceSecurityHeaderHandler(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }
    @Override
    public boolean handleMessage(SOAPMessageContext messageContext) {
        boolean direction = ((Boolean) messageContext.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).booleanValue();
        if (direction) {
            try {
                SOAPEnvelope envelope = messageContext.getMessage().getSOAPPart().getEnvelope();
                SOAPFactory soapFactory = SOAPFactory.newInstance();
                // WSSecurity <Security> header
                SOAPElement wsSecHeaderElm = soapFactory.createElement("Security", AUTH_PREFIX, AUTH_NS);
                SOAPElement userNameTokenElm = soapFactory.createElement("UsernameToken", AUTH_PREFIX, AUTH_NS);
                SOAPElement userNameElm = soapFactory.createElement("Username", AUTH_PREFIX, AUTH_NS);
                userNameElm.addTextNode(this.userName);
                SOAPElement passwdElm = soapFactory.createElement("Password", AUTH_PREFIX, AUTH_NS);
                passwdElm.addTextNode(this.password);
                userNameTokenElm.addChildElement(userNameElm);
                userNameTokenElm.addChildElement(passwdElm);
                // add child elements to the root element
                wsSecHeaderElm.addChildElement(userNameTokenElm);
                // create SOAPHeader instance for SOAP envelope
                SOAPHeader sh = envelope.getHeader();
                if (sh == null) {
                    envelope.addHeader();
                    sh = envelope.getHeader();
                }
                // add SOAP element for header to SOAP header object
                sh.addChildElement(wsSecHeaderElm);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return true;
    }
    
    public Set<QName> getHeaders() {
        return Collections.EMPTY_SET;
    }
    
    public boolean handleFault(SOAPMessageContext messageContext) {
        return true;
    }
    
    public void close(MessageContext context) {
    }
    
}
