/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package efinansefaturawsconsole;


import java.util.ArrayList;
import java.util.List;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

/**
 *
 * @author osman.cuhadar
 */
public class Login8043 {
    
    public Login8043() {}
    
    Connector8043.ConnectorService port;

    public Login8043(String usrname, String pass) {

        
        try {
            
            Connector8043.ConnectorService_Service service = new Connector8043.ConnectorService_Service();
            this.port = service.getConnectorServicePort();
            this.port = setAuthToPort(port, usrname, pass);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Connector8043.ConnectorService setAuthToPort(Connector8043.ConnectorService port, String username, String password) {
        BindingProvider bp = (BindingProvider) port;
        Binding binding = bp.getBinding();
        List<Handler> handlerChain = new ArrayList<>();
        WebServiceSecurityHeaderHandler wsSecurity = new WebServiceSecurityHeaderHandler(username, password);
        handlerChain.add(wsSecurity);
        binding.setHandlerChain(handlerChain);

        return port;
    }

    
    
}
