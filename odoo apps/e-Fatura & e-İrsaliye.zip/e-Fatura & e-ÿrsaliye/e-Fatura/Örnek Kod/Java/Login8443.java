/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package efinansefaturawsconsole;


import java.util.ArrayList;
import java.util.List;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

/**
 *
 * @author osman.cuhadar
 */
public class Login8443 {
    
    public Login8443() {}
    
    Connector8443.ConnectorService port;

    public Login8443(String usrname, String pass) {

        
        try {
            //URL url = new URL("https://edeftertest.efinans.com.tr/edefter/ws/EDefterWS?wsdl");

            Connector8443.ConnectorService_Service service = new Connector8443.ConnectorService_Service();
            this.port = service.getConnectorServicePort();
            this.port = setAuthToPort(port, usrname, pass);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Connector8443.ConnectorService setAuthToPort(Connector8443.ConnectorService port, String username, String password) {
        BindingProvider bp = (BindingProvider) port;
        Binding binding = bp.getBinding();
        List<Handler> handlerChain = new ArrayList<>();
        WebServiceSecurityHeaderHandler wsSecurity = new WebServiceSecurityHeaderHandler(username, password);
        handlerChain.add(wsSecurity);
        binding.setHandlerChain(handlerChain);

        return port;
    }

    
    
}
