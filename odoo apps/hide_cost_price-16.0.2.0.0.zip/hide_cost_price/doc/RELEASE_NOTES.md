## Module <hide_cost_price>

#### 02.09.2023
#### Version 16.0.2.0.0
##### ADD
- Initial commit for Hide Cost Price