## Module <hospital_appointments>

#### 10.05.2022
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Patient Appointment Management Module

#### 20.05.2023
#### Version 15.0.1.0.1
#### ADD
- Updated Patient Appointment Form.
