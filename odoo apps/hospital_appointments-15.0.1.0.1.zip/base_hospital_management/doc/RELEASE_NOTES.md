## Module <hospital_management>

#### 10.05.2022
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Hospital Management Module
