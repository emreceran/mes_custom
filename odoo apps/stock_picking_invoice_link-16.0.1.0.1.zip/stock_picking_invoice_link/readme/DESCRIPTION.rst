This module adds a link between pickings and invoices as well as on the lines.
Invoices are generated from sales orders. With this module, you can find back
which deliveries an invoice relates to.

In standard, if you make a partial delivery and invoice it, then make remaining
delivery and invoice it, it is impossible to known to what delivery the
invoices relate to. You only have the quantity.

This module is also useful if you want to present data on the invoice report
grouped by deliveries.

Note that the links are only for products with an invoicing policy set on
delivery.
