## Module <ob_sale_order_line_view>

#### 18.10.2022
#### Version 16.0.0.0.0
#### ADD
Initial commit for Sale Order Line View




