Sale Order Line View
------------------
Supporting Addon for Sales


Configuration
=============
* No additional configurations needed

Company
-------
* `Odoo Bin`

Credits
-------
* Odoo Bin

Contacts
--------
* Mail Contact : odooobin@gmail.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

This module is maintained by Odoo Bin.

Further information
===================
HTML Description: `<static/description/index.html>`__


