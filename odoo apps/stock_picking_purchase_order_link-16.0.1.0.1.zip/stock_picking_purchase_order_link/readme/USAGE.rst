To use this module, you need to:

#. Go to *Purchase > Products* and create one of type "Stockable".
#. Go to *Purchase > Purchase Orders* and create one and confirm.
#. Go to the picking generated clicking in shipment smartbutton.
#. In the picking appears a new smartbutton to navigate to the purchase order
   called *Purchase Order*.
