Added new mixin `generic.mixin.namesearch_by_fields`
