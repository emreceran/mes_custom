Added new base class in tests.common - `WebTourCase` that could be used
to easily run js tours.
