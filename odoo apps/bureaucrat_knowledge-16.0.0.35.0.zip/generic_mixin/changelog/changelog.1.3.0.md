Added mixins and utils for test-cases:
- hide_log_messages (decorator and contextmanager that allow to hide log msgs)
- ReduceLoggingMixin (reduce logging output)
- AccessRulesFixMixinST
- AccessRulesFixMixinMT
