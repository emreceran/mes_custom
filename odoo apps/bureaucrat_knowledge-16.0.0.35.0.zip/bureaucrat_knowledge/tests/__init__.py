from . import (
    test_bureaucrat_knowledge,
    test_knowledge_category_create,
    test_knowledge_category_read,
    test_knowledge_category_write,
    test_knowledge_category_unlink,
    test_knowledge_document_create,
    test_knowledge_document_read,
    test_knowledge_document_write,
    test_knowledge_document_unlink,
    test_knowledge_document_history_read,
    test_knowledge_document_history_edit,
)
