Added support for different types of documents (currently HTML and PDF)
