Added document types as separate model.
Now it is possible to customize available document types.
