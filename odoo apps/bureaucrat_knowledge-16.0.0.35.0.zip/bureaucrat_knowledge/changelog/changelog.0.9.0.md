Added super flexible access rights management for knowledge base
