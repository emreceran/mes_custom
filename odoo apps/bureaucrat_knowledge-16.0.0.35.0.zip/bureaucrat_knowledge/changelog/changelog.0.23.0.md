Added 'sequence' field in document and category settings to set priority view.
