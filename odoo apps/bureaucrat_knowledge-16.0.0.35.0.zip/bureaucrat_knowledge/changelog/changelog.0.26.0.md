Added required codes to bureaucrat knowledge categories
