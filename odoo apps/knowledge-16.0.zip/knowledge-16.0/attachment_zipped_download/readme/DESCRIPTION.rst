This module allows downloading multiple attachments as a zip file.
