#. Go to *Settings > Technical > Database Structure > Attachments* and select some files.
#. Go to *Actions > Download* and a zip file containing the selected files will be downloaded.
