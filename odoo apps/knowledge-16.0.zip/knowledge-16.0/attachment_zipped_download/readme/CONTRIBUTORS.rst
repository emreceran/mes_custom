* César Fernández Domínguez <cesfernandez@outlook.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Víctor Martínez
  * Pedro M. Baeza
