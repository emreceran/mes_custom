* Jonathan Nemry <jonathan.nemry@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Ernesto Tejeda
  * Manuel Calero
  * Víctor Martínez
  * Matias Peralta - Adhoc SA
