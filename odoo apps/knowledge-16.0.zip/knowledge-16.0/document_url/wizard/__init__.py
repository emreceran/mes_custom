# Copyright 2014 Serv. Tecnol. Avanzados (http://www.serviciosbaeza.com)
# Copyright 2014 Tecnativa - Pedro M. Baeza
# Copyright 2016 ACSONE SA/NV (<http://acsone.eu>)
from . import document_url
