To use this module, you need to:

#. Go to Knowledge > Pages
#. Create a new page and choose the previously created category.
#. A notification is sent to the approvers group with a link to the
   page history to review.
#. Depending on the review, the page history is approved or not.
#. Users reading the page see the last approved version.
