* Odoo SA <info@odoo.com>
* Savoir-faire Linux <support@savoirfairelinux.com>
* Gervais Naoussi <gervaisnaoussi@gmail.com>
* Maxime Chambreuil <mchambreuil@opensourceintegrators.com>
* Iván Todorovich <ivan.todorovich@gmail.com>
* Victor M.M. Torres <victor.martin@tecnativa.com>

* `Guadaltech <https://www.guadaltech.es>`_:

  * Fernando La Chica <fernando.lachica@guadaltech.es>
