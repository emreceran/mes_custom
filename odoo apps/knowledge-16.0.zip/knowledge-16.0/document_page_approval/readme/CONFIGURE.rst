To configure this module, you need to:

#. Set a valid email address on the company settings.
#. Go to Knowledge > Categories.
#. Create a new page category and set an approver group.
   Make sure users belonging to that group have valid email addresses.
