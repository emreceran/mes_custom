This module allows to define groups on a category.
