# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api, fields, models, _


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"


    cost_discount = fields.Float("indirim", readonly=False, store=True, groups="base.group_user")


    @api.onchange('cost_discount')
    def onchange_cost_discount(self):
        # self.purchase_price = (1 - self.cost_discount/100) * self.purchase_price
        # print(self.purchase_price)
        for line in self:
            line = line.with_company(line.company_id)
            product_cost = line.product_id.standard_price
            x = line._convert_price(product_cost, line.product_id.uom_id)
            line.purchase_price = (1 - line.cost_discount / 100) * x
            line.margin = line.price_subtotal - (line.price_unit * line.product_uom_qty)
            print(line.purchase_price)

