To enable scheduled currency rates update:

# Go to *Invoicing > Configuration > Settings*
# Ensure *Automatic Currency Rates (OCA)* is checked

To configure currency rates providers:

# Go to *Invoicing > Configuration > Currency Rates Providers*
# Create and configure one or more providers
