# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import res_company
from . import res_config_settings
from . import res_currency_rate
from . import res_currency_rate_provider
from . import res_currency_rate_provider_ECB
